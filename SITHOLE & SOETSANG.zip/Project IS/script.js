const initializeAqualonApp = () => {
  const STORAGE_KEY = 'aqualonUser';
  const SYSTEM_DB_KEY = 'aqualon_system_db';
  const CURRENT_USER_KEY = 'aqualon_currentUser';
  const CURRENT_ROLE_KEY = 'aqualon_currentRole';

  
  function validateName(val, label) {
    const str = String(val || '').trim();
    if (!str) return `${label} is required.`;
    if (!/^[A-Za-z\s]+$/.test(str)) {
      return `${label} must contain only letters (no numbers or special characters).`;
    }
    const words = str.split(/\s+/);
    for (const w of words) {
      if (!/^[A-Z][a-zA-Z]*$/.test(w)) {
        return `${label} must start with a capital letter (e.g. "${w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()}").`;
      }
    }
    return null;
  }

  function validateUsername(val) {
    const str = String(val || '').trim();
    if (!str) return 'Username is required.';
    if (str.length < 3) return 'Username must be at least 3 characters long.';
    const letters = str.match(/[A-Za-z]/g) || [];
    if (letters.length < 3) return 'Username must contain at least 3 letters.';
    return null;
  }

  function validateEmail(val) {
    const str = String(val || '').trim();
    if (!str) return 'Email address is required.';
    if (!str.includes('@')) return "Email address must contain '@'.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(str)) return 'Please provide a valid email address.';
    return null;
  }

  function validatePassword(val) {
    const str = String(val || '');
    if (str.length < 8) return 'Password must have at least 8 characters.';
    if (!/[A-Z]/.test(str)) return 'Password must contain at least 1 capital letter.';
    if (!/[0-9]/.test(str)) return 'Password must contain at least 1 number.';
    const specials = str.match(/[^A-Za-z0-9\s]/g) || [];
    if (specials.length === 0) return 'Password must contain 1 special character (e.g. ! or @ or #).';
    if (specials.length > 1) return 'Password can use only 1 special character.';
    return null;
  }

  function validatePhone(val) {
    const str = String(val || '').trim();
    if (!str) return null;
    if (!str.startsWith('0') && !str.startsWith('+27')) {
      return 'Phone number must begin with 0 or +27.';
    }
    const cleaned = str.replace(/\s+/g, '');
    if (!/^(0|\+27)\d{8,11}$/.test(cleaned)) {
      return 'Phone number must begin with 0 or +27 and contain 9 to 11 digits.';
    }
    return null;
  }

  const facilityData = {
    'joan-harrison': {
      name: 'Joan Harrison Swimming Pools',
      image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRdvG8n6hmZrKKfOyRMbWlxMgqUaK0mBt4f91u6RyYB-9f5FN16LCtHYeYR&s=10',
      location: 'Main Campus'
    },
    'stanmore': {
      name: 'Stanmore Aquatic Centre',
      image: 'https://static.where-e.com/New_Zealand/Auckland/Stanmore-Bay-Pool-And-Leisure-Centre_f8ce6e0c9b13c139975afa1cb55c9f5f.jpg?auto=format&fit=crop&w=600&q=80',
      location: 'North Shore'
    },
    'orient-beach': {
      name: 'Orient Beach & Swimming Pools',
      image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTnqjY6UZwdyTZWQ03Uh4yqHulxRdF-6BjeF4PLNbjCQk5N3OlF6zZ5yk0&s=10?auto=format&fit=crop&w=600&q=80',
      location: ''
    }
  };

  const roleDashboardMap = {
    member: 'dashboard.html',
    staff: 'staff-dashboard.html',
    admin: 'itadmin-dashboard.html',
    itadmin: 'itadmin-dashboard.html'
  };

  const allowedPages = {
    member: [
      'dashboard.html',
      'history.html',
      'booking.html',
      'incident-report.html',
      'incident-view.html',
      'facilities.html',
      'maintenance.html',
      'settings.html',
      'announcement.html'
    ],
    staff: [
      'staff-dashboard.html',
      'staff-incidents.html',
      'staff-maintenance.html',
      'staff-settings.html'
    ],
    admin: [
      'itadmin-dashboard.html',
      'itadmin-addstaff.html',
      'itadmin-editstaff.html',
      'itadmin-incidents.html',
      'itadmin-maintenance.html',
      'itadmin-settings.html',
      'itadmin-stats.html',
      'announcement.html'
    ],
    itadmin: [
      'itadmin-dashboard.html',
      'itadmin-addstaff.html',
      'itadmin-editstaff.html',
      'itadmin-incidents.html',
      'itadmin-maintenance.html',
      'itadmin-settings.html',
      'itadmin-stats.html',
      'announcement.html'
    ]
  };

  function normalizeRole(role) {
    if (!role) return 'member';
    return role === 'itadmin' || role === 'admin' ? 'admin' : role;
  }

  function normalizeFacilityKey(facility) {
    const value = (facility || 'Joan Harrison Swimming Pools').toLowerCase();
    if (value.includes('stanmore')) return 'stanmore';
    if (value.includes('orient')) return 'orient-beach';
    return 'joan-harrison';
  }

  function getDefaultDatabase() {
    // Authentication now lives in SQL Server. Keep only empty local UI caches;
    // never seed plaintext demo passwords into browser storage.
    return { member: {}, staff: {}, itadmin: {}, admin: {} };
  }

  function initializeDatabase() {
    let systemDB = JSON.parse(localStorage.getItem(SYSTEM_DB_KEY) || 'null');

    if (!systemDB) {
      systemDB = getDefaultDatabase();
      localStorage.setItem(SYSTEM_DB_KEY, JSON.stringify(systemDB));
      return;
    }

    if (!systemDB.admin) {
      systemDB.admin = {};
    }

    if (systemDB.itadmin) {
      Object.entries(systemDB.itadmin).forEach(([key, value]) => {
        if (!systemDB.admin[key]) {
          systemDB.admin[key] = { ...value, role: 'admin' };
        }
      });
    }

    localStorage.setItem(SYSTEM_DB_KEY, JSON.stringify(systemDB));
  }

  function getSystemDB() {
    let systemDB = JSON.parse(localStorage.getItem(SYSTEM_DB_KEY) || 'null');

    if (!systemDB) {
      initializeDatabase();
      systemDB = JSON.parse(localStorage.getItem(SYSTEM_DB_KEY) || '{}');
    }

    return systemDB;
  }

  function getCurrentUser() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }

      const legacyUserKey = localStorage.getItem(CURRENT_USER_KEY);
      if (!legacyUserKey) {
        return null;
      }

      const systemDB = getSystemDB();
      for (const role of ['member', 'staff', 'itadmin', 'admin']) {
        const roleUsers = systemDB[role] || {};
        const userRecord = roleUsers[legacyUserKey];
        if (userRecord) {
          return {
            role: normalizeRole(userRecord.role || role),
            email: legacyUserKey,
            name: userRecord.name || 'User',
            facility: userRecord.facility || null,
            profilePicture: userRecord.profilePicture || null
          };
        }
      }

      return null;
    } catch (error) {
      console.error('Unable to read saved session:', error);
      return null;
    }
  }

  function saveCurrentUser(user) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
    localStorage.setItem(CURRENT_USER_KEY, user.email);
    localStorage.setItem(CURRENT_ROLE_KEY, normalizeRole(user.role));
  }

  function clearCurrentUser() {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(CURRENT_USER_KEY);
    localStorage.removeItem(CURRENT_ROLE_KEY);
  }

  function currentPage() {
    return window.location.pathname.split('/').pop() || 'login.html';
  }

  function initializeAuthPageExperience() {
    const page = currentPage();
    const authPages = new Set(['login.html', 'signup.html', 'forgot-password.html']);
    if (!authPages.has(page)) return;

    document.body.classList.add('auth-page', `auth-page-${page.replace('.html', '')}`);
    requestAnimationFrame(() => document.body.classList.add('auth-page-ready'));

    document.querySelectorAll('a[href]').forEach((link) => {
      const target = new URL(link.href, window.location.href);
      const targetPage = target.pathname.split('/').pop();
      if (!authPages.has(targetPage) || targetPage === page) return;

      link.addEventListener('click', (event) => {
        if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button !== 0) return;
        event.preventDefault();
        document.body.classList.add('auth-page-leaving');
        window.setTimeout(() => window.location.assign(link.href), 190);
      });
    });

    const policyDialog = document.getElementById('signup-policy-dialog');
    const policyTitle = document.getElementById('policy-dialog-title');
    const policyContent = document.getElementById('policy-dialog-content');
    if (policyDialog && policyTitle && policyContent) {
      document.querySelectorAll('[data-policy]').forEach((button) => {
        button.addEventListener('click', () => {
          const policy = button.dataset.policy;
          const isPrivacyPolicy = policy === 'privacy';
          const template = document.getElementById(isPrivacyPolicy ? 'privacy-policy-content' : 'terms-policy-content');
          if (!template) return;
          policyTitle.textContent = isPrivacyPolicy ? 'Privacy Policy' : 'Terms of Use';
          policyContent.replaceChildren(template.content.cloneNode(true));
          policyDialog.showModal();
        });
      });

      policyDialog.querySelectorAll('.policy-close').forEach((button) => {
        button.addEventListener('click', () => policyDialog.close());
      });
      policyDialog.addEventListener('click', (event) => {
        if (event.target === policyDialog) policyDialog.close();
      });
    }
  }

  function showLoginError(message) {
    const errorBox = document.getElementById('login-error');
    if (!errorBox) return;
    errorBox.textContent = message;
    errorBox.style.display = 'block';
  }

  function redirectToDashboard(role) {
    const normalizedRole = normalizeRole(role);
    const target = roleDashboardMap[normalizedRole] || 'dashboard.html';
    window.location.href = target;
  }

  function setFacilityCard(user) {
    const facilityKey = getAssignedFacilityKey(user);
    const facility = facilityKey ? facilityData[facilityKey] : null;

    const selectors = [
      ['nav-facility-img', 'src'],
      ['nav-facility-name', 'text'],
      ['nav-admin-name', 'text'],
      ['staff-facility-img', 'src'],
      ['staff-facility-name', 'text'],
      ['staff-user-name', 'text']
    ];

    selectors.forEach(([id, type]) => {
      const element = document.getElementById(id);
      if (!element) return;
      if (type === 'src') {
        if (facility) element.src = facility.image;
      } else {
        if (id === 'nav-admin-name' || id === 'staff-user-name') {
          element.textContent = user && user.name ? user.name : 'User';
        } else {
          element.textContent = facility ? facility.name : 'No facility assigned';
        }
      }
    });

    const memberUserName = document.getElementById('member-user-name');
    if (memberUserName && user && user.name) {
      memberUserName.textContent = user.name;
    }

    const facilityDisplay = document.getElementById('display-facility');
    if (facilityDisplay && facility) {
      facilityDisplay.value = facility.name;
    }

    renderUserAvatars(user);
  }

  function tryLocalLogin(selectedRole, identifier, password) {
    const systemDB = getSystemDB();
    const roleKey = selectedRole === 'admin' ? 'itadmin' : selectedRole;
    const roleUsers = systemDB[roleKey] || {};

    for (const [key, user] of Object.entries(roleUsers)) {
      const matchesUsername = user.username === identifier || key === identifier || user.email === identifier;
      if (matchesUsername && user.password === password) {
        return {
          role: normalizeRole(user.role || selectedRole),
          email: key,
          name: user.name || 'User',
          facility: user.facility || null,
          profilePicture: user.profilePicture || null
        };
      }
    }

    return null;
  }

  initializeDatabase();
  initializeAuthPageExperience();

  const logoutButtons = document.querySelectorAll('#logout-btn, #staff-logout-btn');
  logoutButtons.forEach((button) => {
    button.addEventListener('click', (event) => {
      event.preventDefault();
      clearCurrentUser();
      window.location.href = 'login.html';
    });
  });

  const API_BASE = (window.AQUALON_API_BASE || 'http://localhost:3000').replace(/\/$/, '');
  const loginForm = document.getElementById('login-form') || document.querySelector('form');
  if (loginForm && loginForm.querySelector('input[name="role"]')) {
    loginForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const selectedRoleInput = loginForm.querySelector('input[name="role"]:checked');
      const selectedRole = normalizeRole(selectedRoleInput ? selectedRoleInput.value : 'member');
      const identifierInput = loginForm.querySelector('#login-identifier, input[type="text"]');
      const passwordInput = loginForm.querySelector('#login-password, input[type="password"]');
      const identifier = (identifierInput ? identifierInput.value.trim() : '').toLowerCase();
      const password = passwordInput ? passwordInput.value : '';
      if (!identifier || !password) { showLoginError('Please enter both your email/username and password.'); return; }
      const submit = document.getElementById('login-submit');
      if (submit) { submit.disabled = true; submit.textContent = 'Signing in…'; }
      try {
        const response = await fetch(`${API_BASE}/api/auth/login`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ identifier, password, role: selectedRole })
        });
        const result = await response.json().catch(() => ({}));
        if (result && result.requires2FA) {
          const code = window.prompt(result.message || 'Two-Factor Authentication is enforced for Staff and Admins.\n\nEnter your 6-digit 2FA code:');
          if (!code) {
            if (submit) { submit.disabled = false; submit.textContent = 'Sign In'; }
            return;
          }
          const verifyRes = await fetch(`${API_BASE}/api/auth/login`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ identifier, password, role: selectedRole, twoFactorCode: code.trim() })
          });
          const verifyResult = await verifyRes.json().catch(() => ({}));
          if (!verifyRes.ok) throw new Error(verifyResult.error || '2FA verification failed.');
          saveCurrentUser(verifyResult.user);
          const errorBox = document.getElementById('login-error');
          if (errorBox) errorBox.style.display = 'none';
          redirectToDashboard(verifyResult.user.role);
          return;
        }
        if (!response.ok) throw new Error(result.error || 'Login failed. Check the API and database connection.');
        saveCurrentUser(result.user);
        const errorBox = document.getElementById('login-error');
        if (errorBox) errorBox.style.display = 'none';
        redirectToDashboard(result.user.role);
      } catch (error) {
        showLoginError(error.message || 'Could not reach Aqualon server. Make sure npm start is running.');
      } finally {
        if (submit) { submit.disabled = false; submit.textContent = 'Sign In'; }
      }
    });
  }

  const signupForm = document.getElementById('signup-form');
  if (signupForm) {
    signupForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const firstName = (signupForm.querySelector('#signup-name, input[placeholder*="first name"], input[name="firstName"]') || {}).value || '';
      const lastName = (signupForm.querySelector('#signup-surname, input[placeholder*="last name"], input[name="lastName"]') || {}).value || '';
      const username = (signupForm.querySelector('#signup-username, input[placeholder*="username"], input[name="username"]') || {}).value || '';
      const email = (signupForm.querySelector('#signup-email, input[type="email"]') || {}).value || '';
      const phone = (signupForm.querySelector('#signup-phone, input[type="tel"]') || {}).value || '';
      const gender = (signupForm.querySelector("#signup-gender, select[name=\"gender\"], select") || {}).value || "";
      const password = (signupForm.querySelector('#signup-password, input[type="password"]') || {}).value || '';
      const confirmPassword = (signupForm.querySelector('#signup-confirm-password, input[placeholder*="Confirm"]') || {}).value || '';
      const fnErr = validateName(firstName, 'First name');
      if (fnErr) { showSignupError(fnErr); return; }
      const lnErr = validateName(lastName, 'Last name');
      if (lnErr) { showSignupError(lnErr); return; }
      const uErr = validateUsername(username);
      if (uErr) { showSignupError(uErr); return; }
      const emErr = validateEmail(email);
      if (emErr) { showSignupError(emErr); return; }
      const phErr = validatePhone(phone);
      if (phErr) { showSignupError(phErr); return; }
      const passErr = validatePassword(password);
      if (passErr) { showSignupError(passErr); return; }
      if (password !== confirmPassword) { showSignupError('Passwords do not match.'); return; }
      const submit = signupForm.querySelector('button[type="submit"]');
      if (submit) { submit.disabled = true; submit.textContent = 'Creating account…'; }
      try {
        const response = await fetch(`${API_BASE}/api/auth/signup`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ firstName: firstName.trim(), lastName: lastName.trim(), username: username.trim(), email: email.trim().toLowerCase(), phone: phone.trim(), gender: gender.trim(), password })
        });
        const result = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(result.error || 'Could not create account.');
        saveCurrentUser(result.user);
        window.location.href = 'dashboard.html';
      } catch (error) {
        showSignupError(error.message || 'Could not reach Aqualon server. Make sure npm start is running.');
      } finally {
        if (submit) { submit.disabled = false; submit.textContent = 'Create Account'; }
      }
    });
  }

  const forgotForm = document.getElementById('forgot-password-form');
  if (forgotForm) {
    forgotForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const email = (document.getElementById('reset-email') || {}).value || '';
      const message = document.getElementById('forgot-success');
      const button = forgotForm.querySelector('button[type="submit"]');
      if (message) { message.style.display = 'block'; message.textContent = 'Preparing reset instructions…'; }
      if (button) { button.disabled = true; button.textContent = 'Please wait…'; }
      try {
        const response = await fetch(`${API_BASE}/api/auth/forgot-password`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: email.trim().toLowerCase() }) });
        const result = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(result.error || 'Could not request a reset link.');
        if (message) {
          message.textContent = result.message || 'If the account exists, reset instructions have been prepared.';
          if (result.resetUrl) {
            const link = document.createElement('a'); link.href = result.resetUrl; link.textContent = ' Open your password reset page'; link.style.display = 'block'; link.style.marginTop = '.5rem';
            message.appendChild(link);
            const note = document.createElement('small'); note.textContent = 'Development mode: this link is shown here because SMTP email is not configured.'; note.style.display = 'block'; note.style.marginTop = '.5rem'; message.appendChild(note);
          }
        }
      } catch (error) {
        if (message) message.textContent = error.message || 'Could not reach Aqualon server. Make sure npm start is running.';
      } finally {
        if (button) { button.disabled = false; button.textContent = 'Send Reset Link'; }
      }
    });
  }

  function showSignupError(message) {
    const errorBox = document.getElementById('signup-error');
    if (!errorBox) return;
    errorBox.textContent = message;
    errorBox.style.display = 'block';
  }

  function getMemberBookings(user) {
    try {
      const bookings = JSON.parse(localStorage.getItem('aqualon_bookings') || '[]');
      return bookings.filter((booking) => booking.userEmail === user.email);
    } catch (error) {
      console.error('Unable to read saved bookings:', error);
      return [];
    }
  }

  function formatBookingDate(dateValue) {
    if (!dateValue) return 'Date not set';
    const date = new Date(`${dateValue}T00:00:00`);
    return Number.isNaN(date.getTime()) ? dateValue : date.toLocaleDateString();
  }

  function renderBookingHistory(user) {
    const tableBody = document.getElementById('history-tbody');
    if (!tableBody) return;

    const bookings = getMemberBookings(user).sort((first, second) => String(second.createdAt || '').localeCompare(String(first.createdAt || '')));
    tableBody.replaceChildren();

    if (!bookings.length) {
      const row = tableBody.insertRow();
      const cell = row.insertCell();
      cell.colSpan = 7;
      cell.textContent = 'No bookings yet.';
      return;
    }

    bookings.forEach((booking) => {
      const row = tableBody.insertRow();
      [booking.id, formatBookingDate(booking.date), booking.facility, booking.activity, booking.duration, booking.guests, booking.status].forEach((value) => {
        row.insertCell().textContent = value == null ? '' : String(value);
      });
    });
  }

  function renderUpcomingBookings(user) {
    const container = document.getElementById('upcoming-bookings');
    if (!container) return;

    const today = new Date();
    const todayString = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    const bookings = getMemberBookings(user)
      .filter((booking) => booking.status === 'Active' && booking.date >= todayString)
      .sort((first, second) => first.date.localeCompare(second.date));

    container.replaceChildren();
    if (!bookings.length) {
      const emptyMessage = document.createElement('p');
      emptyMessage.className = 'booking-empty-state';
      emptyMessage.textContent = 'No active upcoming bookings.';
      container.appendChild(emptyMessage);
      return;
    }

    bookings.forEach((booking) => {
      const item = document.createElement('article');
      item.className = 'upcoming-booking-item';

      const heading = document.createElement('h4');
      heading.textContent = booking.facility;
      const detail = document.createElement('p');
      detail.textContent = `${booking.activity} · ${formatBookingDate(booking.date)}`;
      const meta = document.createElement('span');
      meta.textContent = `${booking.guests} guest${Number(booking.guests) === 1 ? '' : 's'} · ${booking.duration}`;
      const reference = document.createElement('small');
      reference.textContent = booking.id;

      item.append(heading, detail, meta, reference);
      container.appendChild(item);
    });
  }

  function getAccountRecord(user) {
    if (!user) {
      try {
        user = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
      } catch (e) {
        user = null;
      }
    }
    if (!user) return null;

    const systemDB = getSystemDB();
    const userRole = normalizeRole(user.role || 'member');
    if (!systemDB[userRole]) {
      systemDB[userRole] = {};
    }

    const email = (user.email || '').toLowerCase().trim();
    const username = (user.username || '').toLowerCase().trim();

    // Check all roles in systemDB for this email or username
    for (const rk of ['staff', 'itadmin', 'admin', 'member']) {
      const roleUsers = systemDB[rk] || {};
      for (const [key, record] of Object.entries(roleUsers)) {
        const recordEmail = (record.email || '').toLowerCase().trim();
        const recordUser = (record.username || '').toLowerCase().trim();
        if (
          (email && key.toLowerCase() === email) ||
          (email && recordEmail === email) ||
          (username && recordUser === username) ||
          (user.name && `${record.name || ''} ${record.surname || ''}`.trim().toLowerCase() === String(user.name).trim().toLowerCase())
        ) {
          return { systemDB, users: roleUsers, record, roleKey: rk };
        }
      }
    }

    // Account not found in legacy mock database: dynamically register it so database users can immediately use all profile features!
    const roleKey = (userRole === 'admin' || userRole === 'itadmin') ? 'itadmin' : userRole;
    if (!systemDB[roleKey]) systemDB[roleKey] = {};

    const nameParts = String(user.name || (email ? email.split('@')[0] : 'User')).trim().split(/\s+/);
    const firstName = nameParts[0] || 'User';
    const lastName = nameParts.slice(1).join(' ') || '';

    const newRecord = {
      email: user.email || `${firstName.toLowerCase()}@aqualon.local`,
      name: firstName,
      surname: lastName,
      role: roleKey,
      facility: user.facility || user.facilityKey || 'stanmore',
      profilePicture: user.profilePicture || '',
      phone: user.phone || ''
    };

    const storageKey = user.email || user.username || newRecord.email;
    systemDB[roleKey][storageKey] = newRecord;
    try {
      localStorage.setItem(SYSTEM_DB_KEY, JSON.stringify(systemDB));
    } catch (e) {
      console.warn('Could not persist systemDB:', e);
    }

    return { systemDB, users: systemDB[roleKey], record: newRecord, roleKey };
  }

  function getAssignedFacilityKey(user) {
    const account = getAccountRecord(user);
    const assignedFacility = (account && account.record.facility) || (user && (user.facilityKey || user.facility));
    return assignedFacility ? normalizeFacilityKey(assignedFacility) : null;
  }

  function getDisplayName(user, record) {
    if (record) {
      const fullName = `${record.name || ''} ${record.surname || ''}`.trim();
      if (fullName) return fullName;
    }
    return user.name || 'User';
  }

  function getProfileInitials(name) {
    const words = String(name || 'User').trim().split(/\s+/).filter(Boolean);
    if (words.length === 1) return words[0].slice(0, 2).toUpperCase();
    return `${words[0][0]}${words[words.length - 1][0]}`.toUpperCase();
  }

  function getProfilePicture(user) {
    const account = getAccountRecord(user);
    return account?.record.profilePicture || user.profilePicture || '';
  }

  function renderUserAvatars(user) {
    const account = getAccountRecord(user);
    const fullName = getDisplayName(user, account && account.record);
    const initials = getProfileInitials(fullName);
    const profilePicture = account?.record.profilePicture || user.profilePicture || '';

    document.querySelectorAll('.user-avatar').forEach((avatar) => {
      avatar.textContent = profilePicture ? '' : initials;
      avatar.style.backgroundImage = profilePicture ? `url("${profilePicture}")` : '';
      avatar.style.backgroundSize = profilePicture ? 'cover' : '';
      avatar.style.backgroundPosition = profilePicture ? 'center' : '';
      avatar.style.backgroundRepeat = profilePicture ? 'no-repeat' : '';
      avatar.setAttribute('role', 'img');
      avatar.setAttribute('aria-label', profilePicture ? `${fullName} profile picture` : `${fullName} initials`);
    });
  }

  function resizeProfileImage(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error('Could not read this image.'));
      reader.onload = () => {
        const image = new Image();
        image.onerror = () => reject(new Error('This file is not a supported image.'));
        image.onload = () => {
          const maxDimension = 384;
          const scale = Math.min(1, maxDimension / Math.max(image.width, image.height));
          const canvas = document.createElement('canvas');
          canvas.width = Math.max(1, Math.round(image.width * scale));
          canvas.height = Math.max(1, Math.round(image.height * scale));
          const context = canvas.getContext('2d');
          if (!context) {
            reject(new Error('Could not process this image.'));
            return;
          }
          context.drawImage(image, 0, 0, canvas.width, canvas.height);
          resolve(canvas.toDataURL('image/jpeg', 0.82));
        };
        image.src = String(reader.result);
      };
      reader.readAsDataURL(file);
    });
  }

  function initializeProfilePicture(user) {
    const form = document.getElementById('profile-photo-form');
    if (!form) return;

    const input = document.getElementById('profile-photo-input');
    const preview = document.getElementById('profile-photo-preview');
    const removeButton = document.getElementById('remove-profile-photo');
    const message = document.getElementById('profile-photo-message');
    const API_BASE = (window.AQUALON_API_BASE || 'http://localhost:3000').replace(/\/$/, '');
    let pendingPicture = '';

    function setMessage(text, isError) {
      if (!message) return;
      message.textContent = text;
      message.className = isError ? 'error-message' : 'success-message';
      message.style.color = isError ? '#dc2626' : '#16a34a';
    }

    function showProfilePicture(picture) {
      const account = getAccountRecord(user);
      const fullName = getDisplayName(user, account && account.record);
      const initials = getProfileInitials(fullName);
      if (!preview) return;
      preview.textContent = picture ? '' : initials;
      preview.style.backgroundImage = picture ? `url("${picture}")` : '';
      preview.style.backgroundSize = picture ? 'cover' : '';
      preview.style.backgroundPosition = picture ? 'center' : '';
      preview.style.backgroundRepeat = picture ? 'no-repeat' : '';
    }

    // Initial display
    let currentPic = getProfilePicture(user);
    showProfilePicture(currentPic);

    // If no picture stored locally, fetch from SQL Server
    const userIdent = user ? (user.email || user.username || '') : '';
    if (!currentPic && userIdent) {
      fetch(`${API_BASE}/api/profile/picture?identifier=${encodeURIComponent(userIdent)}`)
        .then((r) => (r.ok ? r.json() : null))
        .then((data) => {
          if (data && data.profilePicture) {
            currentPic = data.profilePicture;
            if (user) {
              user.profilePicture = currentPic;
              saveCurrentUser(user);
            }
            const acc = getAccountRecord(user);
            if (acc && acc.record) {
              acc.record.profilePicture = currentPic;
              try { localStorage.setItem(SYSTEM_DB_KEY, JSON.stringify(acc.systemDB)); } catch {}
            }
            showProfilePicture(currentPic);
            renderUserAvatars(user);
          }
        })
        .catch(() => {});
    }

    if (input) {
      input.addEventListener('change', async () => {
        const file = input.files && input.files[0];
        if (!file) return;
        if (!file.type.startsWith('image/')) {
          setMessage('Choose an image file.', true);
          input.value = '';
          return;
        }
        if (file.size > 8 * 1024 * 1024) {
          setMessage('This image is too large. Choose one under 8 MB.', true);
          input.value = '';
          return;
        }

        try {
          pendingPicture = await resizeProfileImage(file);
          showProfilePicture(pendingPicture);
          setMessage('Preview ready. Click "Save Picture" to apply across your portal.', false);
        } catch (error) {
          pendingPicture = '';
          setMessage(error.message, true);
        }
      });
    }

    form.addEventListener('submit', (event) => {
      event.preventDefault();
      if (!pendingPicture) {
        setMessage('Choose a picture before saving.', true);
        return;
      }

      const account = getAccountRecord(user);
      if (account && account.record) {
        account.record.profilePicture = pendingPicture;
        try { localStorage.setItem(SYSTEM_DB_KEY, JSON.stringify(account.systemDB)); } catch {}
      }

      if (user) {
        user.profilePicture = pendingPicture;
        saveCurrentUser(user);
      }

      renderUserAvatars(user);
      showProfilePicture(pendingPicture);
      setMessage('Profile picture updated successfully!', false);

      // Persist to SQL Server
      if (userIdent) {
        fetch(`${API_BASE}/api/profile/picture`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: userIdent, profilePicture: pendingPicture })
        }).catch((err) => console.warn('[Aqualon Profile] Picture server sync:', err.message));
      }

      pendingPicture = '';
      if (input) input.value = '';
    });

    if (removeButton) {
      removeButton.addEventListener('click', () => {
        const account = getAccountRecord(user);
        if (account && account.record) {
          delete account.record.profilePicture;
          try { localStorage.setItem(SYSTEM_DB_KEY, JSON.stringify(account.systemDB)); } catch {}
        }

        if (user) {
          delete user.profilePicture;
          saveCurrentUser(user);
        }

        renderUserAvatars(user);
        showProfilePicture('');
        pendingPicture = '';
        if (input) input.value = '';
        setMessage('Your initials will be shown instead of a picture.', false);

        if (userIdent) {
          fetch(`${API_BASE}/api/profile/picture`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: userIdent, profilePicture: '' })
          }).catch(() => {});
        }
      });
    }
  }

  function getIncidents() {
    try {
      const incidents = JSON.parse(localStorage.getItem('aqualon_incidents') || '[]');
      return Array.isArray(incidents) ? incidents : [];
    } catch (error) {
      return [];
    }
  }

  function saveIncidents(incidents) {
    localStorage.setItem('aqualon_incidents', JSON.stringify(incidents));
  }

  function getReporterRoleLabel(role) {
    if (role === 'itadmin' || role === 'admin') return 'IT Admin';
    if (role === 'staff') return 'Staff';
    return 'Member';
  }

  function renderIncidentRows(user) {
    const page = currentPage();
    const tableBody = document.getElementById(page === 'itadmin-incidents.html' ? 'admin-incident-tbody' : 'incident-tbody');
    if (!tableBody) return;

    const assignedFacilityKey = getAssignedFacilityKey(user);
    const reporterFilter = document.getElementById('reporter-filter')?.value || 'all';
    let incidents = getIncidents();

    if (page === 'incident-view.html') {
      incidents = incidents.filter((incident) => incident.reporterEmail === user.email);
    } else if (page === 'staff-incidents.html' || page === 'itadmin-incidents.html') {
      incidents = assignedFacilityKey
        ? incidents.filter((incident) => incident.facilityKey === assignedFacilityKey)
        : [];
      if (page === 'itadmin-incidents.html' && reporterFilter !== 'all') {
        incidents = incidents.filter((incident) => incident.reporterRole === reporterFilter);
      }
    } else {
      return;
    }

    incidents.sort((first, second) => String(second.submittedAt || '').localeCompare(String(first.submittedAt || '')));
    tableBody.replaceChildren();

    if (!incidents.length) {
      const row = tableBody.insertRow();
      const cell = row.insertCell();
      cell.colSpan = page === 'incident-view.html' ? 6 : page === 'staff-incidents.html' ? 8 : 9;
      cell.textContent = 'No incident reports found for this view.';
      return;
    }

    incidents.forEach((incident) => {
      const row = tableBody.insertRow();
      const values = page === 'incident-view.html'
        ? [incident.id, incident.date, incident.facility, incident.type, incident.description, incident.status]
        : page === 'staff-incidents.html'
          ? [incident.id, incident.date, incident.facility, incident.reporterName, incident.type, incident.description, incident.status]
          : [incident.id, incident.date, incident.facility, incident.reporterName, getReporterRoleLabel(incident.reporterRole), incident.type, incident.description, incident.status];

      values.forEach((value) => {
        row.insertCell().textContent = value || '';
      });

      if (page !== 'incident-view.html') {
        const actionCell = row.insertCell();
        const statusButton = document.createElement('button');
        statusButton.type = 'button';
        statusButton.className = 'btn-secondary incident-status-btn';
        statusButton.textContent = incident.status === 'Resolved' ? 'Reopen' : 'Mark Resolved';
        statusButton.addEventListener('click', () => {
          const allIncidents = getIncidents();
          const targetIncident = allIncidents.find((item) => item.id === incident.id);
          const currentFacilityKey = getAssignedFacilityKey(user);
          const canManageIncident = ['staff', 'admin'].includes(normalizeRole(user.role))
            && currentFacilityKey
            && targetIncident
            && targetIncident.facilityKey === currentFacilityKey;
          if (!canManageIncident) return;
          targetIncident.status = targetIncident.status === 'Resolved' ? 'Open' : 'Resolved';
          targetIncident.updatedAt = new Date().toISOString();
          saveIncidents(allIncidents);
          renderIncidentRows(user);
        });
        actionCell.appendChild(statusButton);
      }
    });
  }

  function initializeIncidentWorkflow(user) {
    const reportForm = document.getElementById('incident-form');
    if (reportForm) {
      reportForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const facility = document.getElementById('incident-facility').value;
        const incident = {
          id: `AQL-INC-${Date.now()}`,
          date: document.getElementById('incident-date').value,
          facility,
          facilityKey: normalizeFacilityKey(facility),
          type: document.getElementById('incident-type').value,
          description: document.getElementById('incident-desc').value.trim(),
          reporterEmail: user.email,
          reporterName: getDisplayName(user, getAccountRecord(user)?.record),
          reporterRole: user.role || 'member',
          status: 'Open',
          submittedAt: new Date().toISOString()
        };

        const incidents = getIncidents();
        incidents.push(incident);
        saveIncidents(incidents);

        const success = document.getElementById('incident-success');
        if (success) success.textContent = `Incident ${incident.id} submitted and shared with facility staff.`;
        reportForm.reset();
      });
    }

    const reporterFilter = document.getElementById('reporter-filter');
    if (reporterFilter) {
      reporterFilter.addEventListener('change', () => renderIncidentRows(user));
    }

    renderIncidentRows(user);
  }

  function createDefaultAnnouncements() {
    const now = Date.now();
    return [
      {
        id: 'aqualon-seed-maintenance',
        title: 'Pool Maintenance Update',
        category: 'Maintenance',
        body: 'Stanmore Aquatic Centre closed early on Friday for routine servicing.',
        facilityKey: 'stanmore',
        status: 'published',
        publishedAt: new Date(now - 2 * 60 * 60 * 1000).toISOString(),
        expiry: ''
      },
      {
        id: 'aqualon-seed-hours',
        title: 'Holiday Operating Hours',
        category: 'Schedule',
        body: 'Check adjusted public holiday schedules across all complexes.',
        facilityKey: '',
        status: 'published',
        publishedAt: new Date(now - 24 * 60 * 60 * 1000).toISOString(),
        expiry: ''
      },
      {
        id: 'aqualon-seed-systems',
        title: 'Wi-Fi & Facility Systems',
        category: 'Systems',
        body: 'Wi-Fi networks will undergo brief maintenance on Saturday from 1 AM - 4 AM.',
        facilityKey: '',
        status: 'published',
        publishedAt: new Date(now - 2 * 24 * 60 * 60 * 1000).toISOString(),
        expiry: ''
      }
    ];
  }

  function getAnnouncements() {
    const storageKey = 'aqualon_announcements';
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved === null) {
        const defaults = createDefaultAnnouncements();
        localStorage.setItem(storageKey, JSON.stringify(defaults));
        return defaults;
      }
      const announcements = JSON.parse(saved);
      return Array.isArray(announcements) ? announcements : [];
    } catch (error) {
      return [];
    }
  }

  function saveAnnouncements(announcements) {
    localStorage.setItem('aqualon_announcements', JSON.stringify(announcements));
  }

  function isAnnouncementCurrent(announcement) {
    if (announcement.status !== 'published') return false;
    if (!announcement.expiry) return true;
    const now = new Date();
    const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    return announcement.expiry >= today;
  }

  function getAnnouncementsForUser(user) {
    const role = normalizeRole(user.role);
    const assignedFacilityKey = getAssignedFacilityKey(user);
    return getAnnouncements()
      .filter((announcement) => isAnnouncementCurrent(announcement))
      .filter((announcement) => role === 'member'
        || !announcement.facilityKey
        || announcement.facilityKey === assignedFacilityKey)
      .sort((first, second) => String(second.publishedAt || '').localeCompare(String(first.publishedAt || '')));
  }

  function formatAnnouncementAge(publishedAt) {
    const time = new Date(publishedAt || Date.now()).getTime();
    const minutes = Math.max(0, Math.floor((Date.now() - time) / 60000));
    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes} minute${minutes === 1 ? '' : 's'} ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} hour${hours === 1 ? '' : 's'} ago`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `${days} day${days === 1 ? '' : 's'} ago`;
    return new Date(publishedAt).toLocaleDateString();
  }

  function renderAnnouncementList(list, announcements) {
    if (!list) return;
    list.replaceChildren();

    if (!announcements.length) {
      const emptyItem = document.createElement('li');
      const emptyMessage = document.createElement('p');
      emptyMessage.className = 'announcement-empty-state';
      emptyMessage.textContent = 'There are no current announcements.';
      emptyItem.appendChild(emptyMessage);
      list.appendChild(emptyItem);
      return;
    }

    const circleClasses = { Maintenance: 'blue', Schedule: 'yellow', Systems: 'green', General: 'blue' };
    announcements.forEach((announcement) => {
      const item = document.createElement('li');
      const indicator = document.createElement('span');
      indicator.className = `status-circle ${circleClasses[announcement.category] || 'blue'}`;
      const content = document.createElement('div');
      content.className = 'announcement-content';
      const title = document.createElement('h4');
      title.textContent = announcement.title;
      const body = document.createElement('p');
      body.textContent = announcement.body;
      const age = document.createElement('span');
      age.className = 'time-ago';
      age.textContent = formatAnnouncementAge(announcement.publishedAt);
      content.append(title, body, age);
      item.append(indicator, content);
      list.appendChild(item);
    });
  }

  function renderAnnouncementAdminTable(user) {
    const tableBody = document.getElementById('announcement-tbody');
    if (!tableBody) return;

    const facilityKey = getAssignedFacilityKey(user);
    const facilityLabel = document.getElementById('announcement-facility-label');
    const facility = facilityKey ? facilityData[facilityKey] : null;
    if (facilityLabel) facilityLabel.textContent = facility ? facility.name : 'No facility assigned';

    const announcements = getAnnouncements()
      .filter((announcement) => announcement.facilityKey === facilityKey)
      .sort((first, second) => String(second.publishedAt || '').localeCompare(String(first.publishedAt || '')));
    tableBody.replaceChildren();

    if (!announcements.length) {
      const row = tableBody.insertRow();
      const cell = row.insertCell();
      cell.colSpan = 6;
      cell.textContent = 'No announcements have been created for this facility.';
      return;
    }

    announcements.forEach((announcement) => {
      const row = tableBody.insertRow();
      [announcement.title, announcement.category, new Date(announcement.publishedAt).toLocaleDateString()].forEach((value) => {
        row.insertCell().textContent = value || '';
      });
      const statusCell = row.insertCell();
      const status = document.createElement('span');
      status.className = `status-badge ${announcement.status === 'published' ? 'published' : 'pending'}`;
      status.textContent = announcement.status === 'published' ? 'Published' : 'Draft';
      statusCell.appendChild(status);
      row.insertCell().textContent = announcement.expiry || '-';
      const actionsCell = row.insertCell();
      const deleteButton = document.createElement('button');
      deleteButton.type = 'button';
      deleteButton.className = 'btn-action';
      deleteButton.textContent = 'Delete';
      deleteButton.addEventListener('click', () => {
        saveAnnouncements(getAnnouncements().filter((item) => item.id !== announcement.id));
        renderAnnouncementAdminTable(user);
        renderAnnouncementFeeds(user);
      });
      actionsCell.appendChild(deleteButton);
    });
  }

  function renderAnnouncementFeeds(user) {
    const announcements = getAnnouncementsForUser(user);
    renderAnnouncementList(document.getElementById('member-announcement-list'), announcements);
    renderAnnouncementList(document.getElementById('staff-announcements-list'), announcements);

    const staffCount = document.getElementById('staff-announcement-count');
    if (staffCount) staffCount.textContent = String(announcements.length);

    const memberModal = document.getElementById('announcements-modal');
    if (memberModal && memberModal.style.display !== 'none') {
      renderAnnouncementList(document.querySelector('#announcements-modal-body .announcement-list'), announcements);
    }
  }

  function initializeAnnouncementWorkflow(user) {
    const form = document.getElementById('announcement-form');
    if (form) {
      form.addEventListener('submit', (event) => {
        event.preventDefault();
        const facilityKey = getAssignedFacilityKey(user);
        const message = document.getElementById('announcement-message');
        if (!facilityKey) {
          if (message) message.textContent = 'This account has no assigned facility and cannot publish announcements.';
          return;
        }

        const announcement = {
          id: `AQL-ANN-${Date.now()}`,
          title: document.getElementById('announce-title').value.trim(),
          category: document.getElementById('announce-category').value,
          body: document.getElementById('announce-body').value.trim(),
          expiry: document.getElementById('announce-expiry').value,
          status: document.getElementById('announce-status').value,
          facilityKey,
          authorEmail: user.email,
          publishedAt: new Date().toISOString()
        };
        saveAnnouncements([...getAnnouncements(), announcement]);
        form.reset();
        if (message) message.textContent = announcement.status === 'published'
          ? 'Announcement published to the member and assigned staff dashboards.'
          : 'Announcement saved as a draft.';
        renderAnnouncementAdminTable(user);
        renderAnnouncementFeeds(user);
      });
    }

    const staffViewAll = document.getElementById('staff-announcement-view-all');
    const staffModal = document.getElementById('staff-announcements-modal');
    const staffClose = document.getElementById('close-staff-announcements');
    const staffFacility = document.getElementById('staff-announcements-facility');
    const assignedFacilityKey = getAssignedFacilityKey(user);
    const facility = assignedFacilityKey ? facilityData[assignedFacilityKey] : null;
    if (staffFacility) staffFacility.textContent = facility ? facility.name : 'No facility assigned';

    function closeStaffAnnouncements() {
      if (!staffModal) return;
      staffModal.hidden = true;
      staffViewAll?.setAttribute('aria-expanded', 'false');
      staffViewAll?.focus();
    }

    if (staffViewAll && staffModal) {
      staffModal.addEventListener('click', (event) => {
        if (event.target === staffModal) closeStaffAnnouncements();
      });
      staffViewAll.addEventListener('click', () => {
        renderAnnouncementFeeds(user);
        staffModal.hidden = false;
        staffViewAll.setAttribute('aria-expanded', 'true');
        staffClose?.focus();
      });
      staffClose?.addEventListener('click', closeStaffAnnouncements);
      document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && !staffModal.hidden) closeStaffAnnouncements();
      });
    }

    window.addEventListener('storage', (event) => {
      if (event.key !== 'aqualon_announcements') return;
      renderAnnouncementFeeds(user);
      renderAnnouncementAdminTable(user);
    });

    renderAnnouncementFeeds(user);
    renderAnnouncementAdminTable(user);
  }

  function getMaintenanceReports() {
    try {
      const reports = JSON.parse(localStorage.getItem('aqualon_maintenance_reports') || '[]');
      return Array.isArray(reports) ? reports : [];
    } catch (error) {
      return [];
    }
  }

  function saveMaintenanceReports(reports) {
    localStorage.setItem('aqualon_maintenance_reports', JSON.stringify(reports));
  }

  function createMaintenanceCell(row, value) {
    const cell = row.insertCell();
    cell.textContent = value == null ? '' : String(value);
    return cell;
  }

  function createMaintenanceBadge(row, value, classPrefix) {
    const cell = row.insertCell();
    const badge = document.createElement('span');
    const normalizedValue = String(value || '').toLowerCase().replace(/\s+/g, '-');
    badge.className = `${classPrefix} ${normalizedValue}`;
    badge.textContent = value || '';
    cell.appendChild(badge);
  }

  function renderMaintenanceReports(user) {
    const page = currentPage();
    const tableId = page === 'staff-maintenance.html'
      ? 'staff-maint-tbody'
      : page === 'itadmin-maintenance.html'
        ? 'admin-maint-tbody'
        : page === 'maintenance.html'
          ? 'member-maintenance-tbody'
          : null;
    if (!tableId) return;

    const tableBody = document.getElementById(tableId);
    if (!tableBody) return;

    const assignedFacilityKey = getAssignedFacilityKey(user);
    const selectedFacilityKey = page === 'maintenance.html'
      ? document.getElementById('maintenance-facility-filter')?.value || ''
      : assignedFacilityKey;
    const reports = getMaintenanceReports()
      .filter((report) => page === 'maintenance.html'
        ? Boolean(selectedFacilityKey) && report.facilityKey === selectedFacilityKey
        : Boolean(assignedFacilityKey) && report.facilityKey === assignedFacilityKey)
      .sort((first, second) => String(second.lastUpdated || '').localeCompare(String(first.lastUpdated || '')));
    const facility = assignedFacilityKey ? facilityData[assignedFacilityKey] : null;

    const facilityLabel = document.getElementById(page === 'staff-maintenance.html' ? 'staff-maint-facility-label' : 'admin-facility-label');
    if (facilityLabel) facilityLabel.textContent = facility ? facility.name : 'No facility assigned';

    tableBody.replaceChildren();
    if (!reports.length) {
      const row = tableBody.insertRow();
      const cell = row.insertCell();
      cell.colSpan = page === 'maintenance.html' ? 7 : page === 'staff-maintenance.html' ? 6 : 7;
      cell.textContent = page === 'maintenance.html' && !selectedFacilityKey
        ? 'Choose a facility to view its maintenance reports.'
        : 'No maintenance reports have been submitted for this facility.';
      return;
    }

    reports.forEach((report) => {
      const row = tableBody.insertRow();
      createMaintenanceCell(row, report.date);

      if (page === 'maintenance.html') {
        createMaintenanceCell(row, report.facility);
      }

      createMaintenanceCell(row, report.type);
      createMaintenanceBadge(row, report.priority, 'priority-text');
      createMaintenanceCell(row, report.description);
      createMaintenanceBadge(row, report.status, 'status-badge');

      if (page === 'itadmin-maintenance.html') {
        createMaintenanceCell(row, report.reporterName);
        createMaintenanceCell(row, report.lastUpdated ? new Date(report.lastUpdated).toLocaleString() : '');
      } else if (page === 'maintenance.html') {
        createMaintenanceCell(row, report.lastUpdated ? new Date(report.lastUpdated).toLocaleDateString() : '');
      } else {
        const actionCell = row.insertCell();
        const editButton = document.createElement('button');
        editButton.type = 'button';
        editButton.className = 'btn-action';
        editButton.textContent = 'Edit';
        editButton.addEventListener('click', () => {
          const form = document.getElementById('staff-maintenance-form');
          if (!form || report.reporterEmail !== user.email || report.facilityKey !== getAssignedFacilityKey(user)) return;
          form.dataset.editingReportId = report.id;
          document.getElementById('maint-type').value = report.type;
          document.getElementById('maint-priority').value = report.priority;
          document.getElementById('maint-description').value = report.description;
          document.getElementById('maint-status').value = report.status;
          document.getElementById('maint-date').value = report.date;
          form.querySelector('button[type="submit"]').textContent = 'Save Report Changes';
          form.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
        actionCell.appendChild(editButton);
      }
    });
  }

  function initializeMaintenanceWorkflow(user) {
    const form = document.getElementById('staff-maintenance-form');
    if (form) {
      const dateInput = document.getElementById('maint-date');
      if (dateInput && !dateInput.value) {
        const today = new Date();
        dateInput.value = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
      }

      form.addEventListener('submit', (event) => {
        event.preventDefault();
        const reports = getMaintenanceReports();
        const editingId = form.dataset.editingReportId;
        const now = new Date().toISOString();
        const facilityKey = getAssignedFacilityKey(user);
        if (!facilityKey) {
          const message = document.getElementById('maintenance-success');
          if (message) message.textContent = 'This account has no assigned facility and cannot submit maintenance reports.';
          return;
        }
        const updatedReport = {
          id: editingId || `AQL-MNT-${Date.now()}`,
          date: document.getElementById('maint-date').value,
          facility: (facilityData[facilityKey] || facilityData['joan-harrison']).name,
          facilityKey,
          type: document.getElementById('maint-type').value,
          priority: document.getElementById('maint-priority').value,
          description: document.getElementById('maint-description').value.trim(),
          status: document.getElementById('maint-status').value,
          reporterEmail: user.email,
          reporterName: getDisplayName(user, getAccountRecord(user)?.record),
          submittedAt: now,
          lastUpdated: now
        };

        if (editingId) {
          const index = reports.findIndex((report) => report.id === editingId
            && report.reporterEmail === user.email
            && report.facilityKey === facilityKey);
          if (index === -1) return;
          updatedReport.submittedAt = reports[index].submittedAt;
          reports[index] = updatedReport;
        } else {
          reports.push(updatedReport);
        }

        saveMaintenanceReports(reports);
        form.reset();
        delete form.dataset.editingReportId;
        form.querySelector('button[type="submit"]').textContent = 'Submit Maintenance Report';
        if (dateInput) {
          const today = new Date();
          dateInput.value = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
        }
        const message = document.getElementById('maintenance-success');
        if (message) message.textContent = editingId ? 'Maintenance report updated.' : 'Maintenance report submitted.';
        renderMaintenanceReports(user);
      });

      form.addEventListener('reset', () => {
        delete form.dataset.editingReportId;
        const submitButton = form.querySelector('button[type="submit"]');
        if (submitButton) submitButton.textContent = 'Submit Maintenance Report';
      });
    }

    const facilityFilter = document.getElementById('maintenance-facility-filter');
    if (facilityFilter) {
      facilityFilter.addEventListener('change', () => renderMaintenanceReports(user));
    }

    renderMaintenanceReports(user);
  }

  function initializeMemberSettings(user) {
    const settingsForm = document.getElementById('settings-form');
    if (!settingsForm) return;

    const account = getAccountRecord(user);
    const nameField = document.getElementById('settings-name');
    const emailField = document.getElementById('settings-username');
    const passwordField = document.getElementById('settings-password');
    const confirmPasswordField = document.getElementById('settings-confirm-password');
    const message = document.getElementById('settings-message');
    const userDisplay = document.getElementById('user-display');
    const API_BASE = (window.AQUALON_API_BASE || 'http://localhost:3000').replace(/\/$/, '');

    if (nameField) nameField.value = getDisplayName(user, account && account.record);
    if (emailField) emailField.value = user.email || '';
    if (userDisplay) userDisplay.textContent = getDisplayName(user, account && account.record);

    settingsForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      if (message) {
        message.textContent = '';
        message.classList.remove('error-message');
        message.style.color = '#16a34a';
      }

      const password = passwordField.value;
      const confirmation = confirmPasswordField.value;
      if (!password && !confirmation) {
        if (message) {
          message.textContent = 'Please enter a new password to update.';
          message.classList.add('error-message');
          message.style.color = '#dc2626';
        }
        return;
      }

      const passErr = validatePassword(password);
      if (passErr) {
        if (message) {
          message.textContent = passErr;
          message.classList.add('error-message');
          message.style.color = '#dc2626';
        }
        return;
      }

      if (password !== confirmation) {
        if (message) {
          message.textContent = 'The passwords do not match.';
          message.classList.add('error-message');
          message.style.color = '#dc2626';
        }
        return;
      }

      try {
        const response = await fetch(`${API_BASE}/api/auth/change-password`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ identifier: user.email || user.username, newPassword: password })
        });
        const result = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(result.error || 'Password update failed');

        const currentAccount = getAccountRecord(user);
        if (currentAccount && currentAccount.record) {
          currentAccount.record.password = password;
          try { localStorage.setItem(SYSTEM_DB_KEY, JSON.stringify(currentAccount.systemDB)); } catch {}
        }

        passwordField.value = '';
        confirmPasswordField.value = '';
        if (message) {
          message.textContent = 'Password updated in database successfully.';
          message.classList.remove('error-message');
          message.style.color = '#16a34a';
        }
      } catch (err) {
        if (message) {
          message.textContent = err.message;
          message.classList.add('error-message');
          message.style.color = '#dc2626';
        }
      }
    });

    // Delete Account button
    const deleteBtn = document.getElementById('btn-delete-account') || document.getElementById('delete-account-btn');
    const deleteMsg = document.getElementById('delete-account-msg') || document.getElementById('delete-account-message');
    if (deleteBtn) {
      deleteBtn.addEventListener('click', async () => {
        const confirmed = window.confirm('Are you sure you want to permanently delete your Aqualon account? All your personal details and records in the database will be permanently deleted.');
        if (!confirmed) return;

        deleteBtn.disabled = true;
        deleteBtn.textContent = 'Deleting Account…';
        if (deleteMsg) {
          deleteMsg.textContent = 'Removing your records from the database…';
          deleteMsg.style.color = '#dc2626';
        }

        try {
          const res = await fetch(`${API_BASE}/api/member/account`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ identifier: user.email || user.username })
          });
          const data = await res.json().catch(() => ({}));
          if (!res.ok) throw new Error(data.error || 'Account deletion failed');

          // Clean local state
          clearCurrentUser();
          try {
            const systemDB = getSystemDB();
            for (const rk of ['member', 'staff', 'itadmin', 'admin']) {
              if (systemDB[rk]) {
                delete systemDB[rk][user.email];
                delete systemDB[rk][user.username];
              }
            }
            localStorage.setItem(SYSTEM_DB_KEY, JSON.stringify(systemDB));
          } catch {}

          alert('Your account has been permanently deleted from the database. You will now be redirected to the sign in page.');
          window.location.href = 'login.html';
        } catch (err) {
          deleteBtn.disabled = false;
          deleteBtn.textContent = 'Delete Account';
          if (deleteMsg) {
            deleteMsg.textContent = err.message || 'Could not delete account. Check server connection.';
            deleteMsg.style.color = '#dc2626';
          }
        }
      });
    }
  }

  function initializeItAdminSettings(user) {
    if (currentPage() !== 'itadmin-settings.html') return;

    const API_BASE = (window.AQUALON_API_BASE || 'http://localhost:3000').replace(/\/$/, '');
    const pref2fa = document.getElementById('pref-force-2fa');
    const prefMaint = document.getElementById('pref-maintenance-mode');
    const prefRetention = document.getElementById('pref-data-retention');
    const saveBtn = document.getElementById('btn-save-system-prefs');
    const feedback = document.getElementById('system-prefs-feedback');

    async function loadPreferences() {
      try {
        const res = await fetch(`${API_BASE}/api/system-preferences`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        const p = data.preferences || {};
        if (pref2fa) pref2fa.checked = p.force2FA !== false;
        if (prefMaint) prefMaint.checked = Boolean(p.maintenanceMode);
        if (prefRetention) prefRetention.value = p.incidentRetention || 'forever';
      } catch (err) {
        console.warn('[Aqualon Settings] Could not load preferences from database:', err.message);
        try {
          const cached = JSON.parse(localStorage.getItem('aqualon_system_preferences') || '{}');
          if (pref2fa && cached.force2FA !== undefined) pref2fa.checked = Boolean(cached.force2FA);
          if (prefMaint && cached.maintenanceMode !== undefined) prefMaint.checked = Boolean(cached.maintenanceMode);
          if (prefRetention && cached.incidentRetention) prefRetention.value = cached.incidentRetention;
        } catch {}
      }
    }

    async function savePreferences() {
      if (!pref2fa || !prefMaint || !prefRetention) return;
      const payload = {
        force2FA: pref2fa.checked,
        maintenanceMode: prefMaint.checked,
        incidentRetention: prefRetention.value
      };
      if (saveBtn) { saveBtn.disabled = true; saveBtn.textContent = 'Saving…'; }
      if (feedback) feedback.textContent = '';

      try {
        const res = await fetch(`${API_BASE}/api/system-preferences`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.error || 'Failed to save preferences');
        localStorage.setItem('aqualon_system_preferences', JSON.stringify(payload));
        if (feedback) {
          feedback.textContent = '✓ Preferences saved to database successfully.';
          feedback.style.color = '#166534';
          setTimeout(() => { if (feedback) feedback.textContent = ''; }, 3500);
        }
      } catch (err) {
        if (feedback) {
          feedback.textContent = `Could not save: ${err.message}`;
          feedback.style.color = '#dc2626';
        }
      } finally {
        if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = 'Save Preferences'; }
      }
    }

    loadPreferences();
    if (saveBtn) saveBtn.addEventListener('click', savePreferences);
    pref2fa?.addEventListener('change', savePreferences);
    prefMaint?.addEventListener('change', savePreferences);
    prefRetention?.addEventListener('change', savePreferences);
  }

  function initializeStaffSettings(user) {
    if (currentPage() !== 'staff-settings.html') return;

    const API_BASE = (window.AQUALON_API_BASE || 'http://localhost:3000').replace(/\/$/, '');
    const account = getAccountRecord(user);
    const record = account && account.record;
    const fullName = getDisplayName(user, record);
    const facilityKey = normalizeFacilityKey(user.facility || (record && record.facility));
    const facility = facilityData[facilityKey] || facilityData['joan-harrison'];
    const name = document.getElementById('set-name');
    const email = document.getElementById('set-email');
    const hours = document.getElementById('set-hours');
    const assignedFacility = document.getElementById('set-facility');

    if (name) name.textContent = fullName;
    if (email) email.textContent = user.email || (record && record.username) || 'Not available';
    if (hours) hours.textContent = (user && (user.shiftHours || user.workingHours)) || (record && (record.shiftHours || record.workingHours)) || 'Not assigned';
    if (assignedFacility) assignedFacility.textContent = facility.name;

    // Fetch live profile from SQL Server to ensure shift working hours reflect current database assignment
    fetch(`${API_BASE}/api/staff/my-profile?identifier=${encodeURIComponent(user.email || user.username || '')}`)
      .then((res) => (res.ok ? res.json() : null))
      .then((profile) => {
        if (profile && profile.shiftHours) {
          if (hours) hours.textContent = profile.shiftHours;
          if (user) { user.shiftHours = profile.shiftHours; user.workingHours = profile.shiftHours; }
          try { localStorage.setItem(STORAGE_KEY, JSON.stringify(user)); } catch {}
        }
      })
      .catch(() => {});

    // Wire up staff password update form
    const passwordForm = document.getElementById('staff-password-form');
    if (passwordForm) {
      passwordForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        const newPass = document.getElementById('staff-new-password')?.value || '';
        const confirmPass = document.getElementById('staff-confirm-password')?.value || '';
        const msg = document.getElementById('staff-password-message');
        const submitBtn = document.getElementById('staff-update-password-btn');

        if (msg) { msg.textContent = ''; msg.classList.remove('error-message'); }
        if (!newPass || !confirmPass) {
          if (msg) { msg.textContent = 'Please enter and confirm your new password.'; msg.classList.add('error-message'); }
          return;
        }
        const passErr = validatePassword(newPass);
        if (passErr) {
          if (msg) { msg.textContent = passErr; msg.classList.add('error-message'); }
          return;
        }
        if (newPass !== confirmPass) {
          if (msg) { msg.textContent = 'Passwords do not match.'; msg.classList.add('error-message'); }
          return;
        }

        if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Updating in database…'; }
        try {
          const response = await fetch(`${API_BASE}/api/auth/change-password`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              identifier: user.email || user.username,
              newPassword: newPass
            })
          });
          const result = await response.json();
          if (!response.ok) throw new Error(result.error || 'Password update failed');

          const currentAccount = getAccountRecord(user);
          if (currentAccount) {
            currentAccount.record.password = newPass;
            localStorage.setItem(SYSTEM_DB_KEY, JSON.stringify(currentAccount.systemDB));
          }

          const np = document.getElementById('staff-new-password'); if (np) np.value = '';
          const cp = document.getElementById('staff-confirm-password'); if (cp) cp.value = '';
          if (msg) {
            msg.textContent = 'Password updated successfully in SQL Server (PERSON_AUTH).';
            msg.classList.remove('error-message');
          }
        } catch (error) {
          if (msg) {
            msg.textContent = `Could not update password: ${error.message}`;
            msg.classList.add('error-message');
          }
        } finally {
          if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Update Password'; }
        }
      });
    }
  }

  function initializeStaffDashboard(user) {
    if (currentPage() !== 'staff-dashboard.html') return;

    const account = getAccountRecord(user);
    const record = account && account.record;
    const fullName = getDisplayName(user, record);
    const facilityKey = getAssignedFacilityKey(user);
    const facility = facilityKey ? facilityData[facilityKey] : null;
    let shiftHours = (user && (user.shiftHours || user.workingHours)) || (record && (record.shiftHours || record.workingHours)) || 'Not assigned';
    const greetingName = document.getElementById('staff-welcome-name');
    const facilityShortName = document.getElementById('staff-facility-short-name');
    const facilityTitle = document.getElementById('staff-assigned-facility-title');
    const facilityLocation = document.getElementById('staff-assigned-facility-location');
    const detailFacilityName = document.getElementById('staff-detail-facility-name');
    const detailFacilityLocation = document.getElementById('staff-detail-facility-location');
    const detailName = document.getElementById('staff-detail-name');
    const detailHours = document.getElementById('staff-detail-hours');
    const details = document.getElementById('staff-facility-details');
    const detailsToggle = document.getElementById('facility-details-toggle');
    const peakHoursButton = document.getElementById('peak-hours-view-all');
    const peakHoursModal = document.getElementById('peak-hours-modal');
    const closePeakHoursModal = document.getElementById('close-peak-hours-modal');
    const modalFacilityName = document.getElementById('peak-hours-modal-facility');
    const clockInButton = document.getElementById('clock-in-btn');
    const clockOutButton = document.getElementById('clock-out-btn');
    const statusLabel = document.getElementById('shift-status');
    const timeDetails = document.getElementById('shift-time-details');
    const shiftStorageKey = 'aqualon_staff_shifts';
    const memberKey = user.email || 'staff';

    if (greetingName) greetingName.textContent = fullName;
    if (facilityShortName) facilityShortName.textContent = facility ? facility.name.split(' ')[0] : 'Unassigned';
    if (facilityTitle) facilityTitle.textContent = facility ? facility.name : 'No facility assigned';
    if (facilityLocation) facilityLocation.textContent = facility ? facility.location : 'No facility assigned';
    if (detailFacilityName) detailFacilityName.textContent = facility ? facility.name : 'No facility assigned';
    if (detailFacilityLocation) detailFacilityLocation.textContent = facility ? facility.location : 'No facility assigned';
    if (detailName) detailName.textContent = fullName;
    if (detailHours) detailHours.textContent = shiftHours;
    if (modalFacilityName) modalFacilityName.textContent = facility ? facility.name : 'No facility assigned';

    function parseHour(value) {
      const matches = String(value || '').match(/(\d{1,2})(?::\d{2})?\s*(AM|PM)/ig);
      if (!matches || !matches.length) return [];

      function to24Hour(time) {
        const match = time.match(/(\d{1,2})(?::\d{2})?\s*(AM|PM)/i);
        if (!match) return null;
        let hour = Number(match[1]) % 12;
        if (match[2].toUpperCase() === 'PM') hour += 12;
        return hour;
      }

      const startHour = to24Hour(matches[0]);
      if (startHour === null) return [];
      if (matches.length < 2) return [startHour];

      const endHour = to24Hour(matches[1]);
      if (endHour === null || endHour <= startHour) return [startHour];
      const occupiedHours = [];
      for (let hour = startHour; hour < endHour; hour += 1) {
        occupiedHours.push(hour);
      }
      return occupiedHours;
    }

    function getPeakHourCounts() {
      let bookings = [];
      try {
        bookings = JSON.parse(localStorage.getItem('aqualon_bookings') || '[]');
      } catch (error) {
        bookings = [];
      }

      const now = new Date();
      const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
      const hourlyCounts = new Map();
      (Array.isArray(bookings) ? bookings : [])
        .filter((booking) => booking.facilityKey === facilityKey
          && booking.status === 'Active'
          && booking.date >= today)
        .forEach((booking) => {
          const timeDescription = booking.timeSlot || (facilityKey === 'joan-harrison' ? '' : booking.duration);
          parseHour(timeDescription).forEach((hour) => {
            hourlyCounts.set(hour, (hourlyCounts.get(hour) || 0) + 1);
          });
        });

      return { hourlyCounts, maxCount: Math.max(0, ...hourlyCounts.values()) };
    }

    function renderPeakHourChart(target, hourlyCounts, maxCount, showEmptyHours) {
      if (!target) return;
      target.replaceChildren();

      if (!facilityKey) {
        const message = document.createElement('p');
        message.className = 'chart-empty-state';
        message.textContent = 'No facility is assigned to this staff account.';
        target.appendChild(message);
        return;
      }

      const summary = document.createElement('p');
      summary.className = 'peak-hour-summary';
      if (maxCount) {
        const peakHour = Array.from(hourlyCounts.entries()).find(([, count]) => count === maxCount)[0];
        const peakLabel = new Date(2000, 0, 1, peakHour).toLocaleTimeString([], { hour: 'numeric' });
        summary.textContent = `Busiest hour: ${peakLabel} · ${maxCount} booking${maxCount === 1 ? '' : 's'}`;
      } else {
        summary.textContent = 'No upcoming bookings with a scheduled time for this facility.';
      }
      target.appendChild(summary);

      if (!maxCount) return;

      for (let hour = 5; hour <= 19; hour += 1) {
        const count = hourlyCounts.get(hour) || 0;
        if (!count && !showEmptyHours) continue;

        const row = document.createElement('div');
        row.className = 'peak-hour-row';
        const label = document.createElement('span');
        label.className = 'peak-hour-label';
        label.textContent = new Date(2000, 0, 1, hour).toLocaleTimeString([], { hour: 'numeric' });
        const track = document.createElement('div');
        track.className = 'peak-hour-track';
        const bar = document.createElement('span');
        bar.className = 'peak-hour-bar';
        bar.style.width = `${maxCount ? (count / maxCount) * 100 : 0}%`;
        track.appendChild(bar);
        const value = document.createElement('strong');
        value.className = 'peak-hour-count';
        value.textContent = String(count);
        row.append(label, track, value);
        target.appendChild(row);
      }
    }

    function renderPeakHours() {
      const { hourlyCounts, maxCount } = getPeakHourCounts();
      renderPeakHourChart(document.getElementById('peak-chart'), hourlyCounts, maxCount, false);
      renderPeakHourChart(document.getElementById('peak-hours-modal-chart'), hourlyCounts, maxCount, true);
    }

    function closePeakHoursDetails() {
      if (!peakHoursModal) return;
      peakHoursModal.hidden = true;
      if (peakHoursButton) {
        peakHoursButton.setAttribute('aria-expanded', 'false');
        peakHoursButton.focus();
      }
    }

    if (peakHoursButton && peakHoursModal) {
      peakHoursButton.addEventListener('click', () => {
        renderPeakHours();
        peakHoursModal.hidden = false;
        peakHoursButton.setAttribute('aria-expanded', 'true');
        closePeakHoursModal?.focus();
      });
    }

    if (closePeakHoursModal) {
      closePeakHoursModal.addEventListener('click', closePeakHoursDetails);
    }

    if (peakHoursModal) {
      peakHoursModal.addEventListener('click', (event) => {
        if (event.target === peakHoursModal) closePeakHoursDetails();
      });
    }

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && peakHoursModal && !peakHoursModal.hidden) {
        closePeakHoursDetails();
      }
    });

    function getShiftHistory() {
      try {
        const allShifts = JSON.parse(localStorage.getItem(shiftStorageKey) || '{}');
        return Array.isArray(allShifts[memberKey]) ? allShifts[memberKey] : [];
      } catch (error) {
        return [];
      }
    }

    function saveShiftHistory(shifts) {
      let allShifts = {};
      try {
        allShifts = JSON.parse(localStorage.getItem(shiftStorageKey) || '{}');
      } catch (error) {
        allShifts = {};
      }
      allShifts[memberKey] = shifts;
      localStorage.setItem(shiftStorageKey, JSON.stringify(allShifts));
    }

    function formatShiftTime(value) {
      if (!value) return '';
      return new Date(value).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
    }

    function renderShiftStatus() {
      const shifts = getShiftHistory();
      const latestShift = shifts[shifts.length - 1];
      const isClockedIn = Boolean(latestShift && !latestShift.clockOut);

      if (clockInButton) clockInButton.disabled = isClockedIn;
      if (clockOutButton) clockOutButton.disabled = !isClockedIn;

      if (!latestShift) {
        if (statusLabel) statusLabel.textContent = 'Not Clocked In';
        if (timeDetails) timeDetails.textContent = '';
        return;
      }

      if (isClockedIn) {
        if (statusLabel) statusLabel.textContent = 'Clocked In';
        if (timeDetails) timeDetails.textContent = `Since ${formatShiftTime(latestShift.clockIn)}`;
        return;
      }

      if (statusLabel) statusLabel.textContent = 'Clocked Out';
      if (timeDetails) {
        timeDetails.textContent = `In ${formatShiftTime(latestShift.clockIn)} · Out ${formatShiftTime(latestShift.clockOut)}`;
      }
    }

    const API_BASE = (window.AQUALON_API_BASE || 'http://localhost:3000').replace(/\/$/, '');
    async function logClockApi(action, timestamp) {
      try {
        await fetch(`${API_BASE}/api/staff/clock`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: user.email || user.username, staffId: user.staffId || null, action, timestamp })
        });
      } catch (err) {
        console.warn('[Aqualon Clock] Attendance log queued or offline:', err.message);
      }
    }

    // Refresh staff shift hours from SQL Server
    fetch(`${API_BASE}/api/staff/my-profile?identifier=${encodeURIComponent(user.email || user.username || '')}`)
      .then((res) => (res.ok ? res.json() : null))
      .then((profile) => {
        if (profile && profile.shiftHours) {
          shiftHours = profile.shiftHours;
          if (detailHours) detailHours.textContent = shiftHours;
          if (user) { user.shiftHours = shiftHours; user.workingHours = shiftHours; }
          try { localStorage.setItem(STORAGE_KEY, JSON.stringify(user)); } catch {}
        }
      })
      .catch(() => {});

    if (clockInButton) {
      clockInButton.addEventListener('click', () => {
        const shifts = getShiftHistory();
        const currentShift = shifts[shifts.length - 1];
        if (currentShift && !currentShift.clockOut) return;
        const now = new Date().toISOString();
        shifts.push({ clockIn: now, clockOut: null });
        saveShiftHistory(shifts);
        renderShiftStatus();
        logClockApi('CLOCK_IN', now);
      });
    }

    if (clockOutButton) {
      clockOutButton.addEventListener('click', () => {
        const shifts = getShiftHistory();
        const currentShift = shifts[shifts.length - 1];
        if (!currentShift || currentShift.clockOut) return;
        const now = new Date().toISOString();
        currentShift.clockOut = now;
        saveShiftHistory(shifts);
        renderShiftStatus();
        logClockApi('CLOCK_OUT', now);
      });
    }

    if (detailsToggle && details) {
      detailsToggle.addEventListener('click', () => {
        const isExpanded = !details.hidden;
        details.hidden = isExpanded;
        detailsToggle.textContent = isExpanded ? 'View all' : 'Hide details';
        detailsToggle.setAttribute('aria-expanded', String(!isExpanded));
      });
    }

    const incidentButton = document.getElementById('log-incident-btn');
    if (incidentButton) {
      incidentButton.addEventListener('click', () => {
        window.location.href = 'staff-incidents.html';
      });
    }

    window.addEventListener('storage', (event) => {
      if (event.key === 'aqualon_bookings') renderPeakHours();
    });

    renderShiftStatus();
    renderPeakHours();
  }

  const infoButtons = document.querySelectorAll('.view-info-btn');
  infoButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const card = button.closest('.facility-card-item');
      if (!card) return;

      const panel = card.querySelector('.facility-info-panel');
      if (!panel) return;

      const isVisible = panel.style.display === 'block';
      panel.style.display = isVisible ? 'none' : 'block';
      button.textContent = isVisible ? 'View Info' : 'Hide Info';
    });
  });

  const announcementsLink = document.getElementById('announcements-view-all');
  const announcementsModal = document.getElementById('announcements-modal');
  const announcementsModalBody = document.getElementById('announcements-modal-body');
  const closeAnnouncementsButton = document.getElementById('close-announcements-btn');

  function closeAnnouncementsModal() {
    if (!announcementsModal) return;
    announcementsModal.style.display = 'none';
    announcementsModal.setAttribute('aria-hidden', 'true');
    announcementsLink?.setAttribute('aria-expanded', 'false');
    announcementsLink?.focus();
  }

  if (announcementsLink && announcementsModal && announcementsModalBody) {
    announcementsModal.setAttribute('role', 'dialog');
    announcementsModal.setAttribute('aria-modal', 'true');
    announcementsModal.setAttribute('aria-hidden', 'true');
    announcementsLink.setAttribute('aria-expanded', 'false');

    announcementsLink.addEventListener('click', (event) => {
      event.preventDefault();
      const announcementList = document.querySelector('.announcement-list');
      announcementsModalBody.replaceChildren();
      if (announcementList) {
        announcementsModalBody.appendChild(announcementList.cloneNode(true));
      }
      announcementsModal.style.display = 'flex';
      announcementsModal.setAttribute('aria-hidden', 'false');
      announcementsLink.setAttribute('aria-expanded', 'true');
      closeAnnouncementsButton?.focus();
    });

    closeAnnouncementsButton?.addEventListener('click', closeAnnouncementsModal);
    announcementsModal.addEventListener('click', (event) => {
      if (event.target === announcementsModal) closeAnnouncementsModal();
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && announcementsModal.style.display !== 'none') {
        closeAnnouncementsModal();
      }
    });
  }

  function initializeAdminStaffPages(user) {
    const page = currentPage();
    const facilityName = user?.facility || user?.facilityName || '';
    const facilityId = Number(user?.facilityId || user?.facility_id || 0) || null;
    const API_BASE = (window.AQUALON_API_BASE || 'http://localhost:3000').replace(/\/$/, '');

    async function api(path, options = {}) {
      const response = await fetch(`${API_BASE}${path}`, {
        ...options,
        headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error || `Request failed (${response.status})`);
      return result;
    }

    if (page === 'itadmin-addstaff.html') {
      const form = document.getElementById('add-staff-form');
      if (!form) return;
      const facilityInput = document.getElementById('display-facility');
      if (facilityInput) facilityInput.value = facilityName || 'Assigned facility';
      form.addEventListener('submit', async (event) => {
        event.preventDefault();
        const button = form.querySelector('button[type="submit"]');
        const orig = button?.textContent;
        if (button) { button.disabled = true; button.textContent = 'Saving to database…'; }
        try {
          let resolvedFacilityId = facilityId;
          if (!resolvedFacilityId) {
            const { facilities = [] } = await api('/api/facilities');
            const normalized = String(facilityName).trim().toLowerCase();
            const selected = facilities.find(f => String(f.FNAME || '').trim().toLowerCase() === normalized) || facilities[0];
            resolvedFacilityId = selected?.FACILITY_ID;
          }
          if (!resolvedFacilityId) throw new Error('No facility is available in SQL Server. Add a facility first.');
          const response = await api('/api/staff', {
            method: 'POST',
            body: JSON.stringify({
              firstName: document.getElementById('add-staff-name').value.trim(),
              lastName: document.getElementById('add-staff-surname').value.trim(),
              email: document.getElementById('add-staff-email').value.trim(),
              phone: document.getElementById('add-staff-phone').value.trim(),
              password: document.getElementById('add-staff-password').value,
              facilityId: resolvedFacilityId,
              shiftHours: document.getElementById('add-staff-shift')?.value || 'Not assigned'
            })
          });
          alert(`Staff member saved to PERSONS and STAFF (Person ID ${response.personId}).`);
          form.reset();
          if (facilityInput) facilityInput.value = facilityName || 'Assigned facility';
        } catch (error) {
          alert(`Could not add staff: ${error.message}`);
        } finally {
          if (button) { button.disabled = false; button.textContent = orig || 'Add Staff Member'; }
        }
      });
      return;
    }

    if (page !== 'itadmin-editstaff.html') return;
    const tableBody = document.getElementById('edit-staff-table-body');
    const form = document.getElementById('update-staff-form');
    const container = document.getElementById('edit-form-container');
    const subtitle = document.getElementById('facility-subtitle');
    if (subtitle) subtitle.textContent = facilityName ? `Staff assigned to ${facilityName}` : 'Staff roster';
    if (!tableBody || !form || !container) return;

    let staffRecords = [];
    function field(record, ...names) {
      for (const name of names) if (record[name] !== undefined && record[name] !== null) return record[name];
      return '';
    }
    function render() {
      tableBody.replaceChildren();
      if (!staffRecords.length) {
        const row = tableBody.insertRow(); const cell = row.insertCell();
        cell.colSpan = 5; cell.textContent = 'No staff records found in the database.'; return;
      }
      staffRecords.forEach((staff) => {
        const row = tableBody.insertRow();
        const name = `${field(staff, 'FIRSTNAME', 'firstName')} ${field(staff, 'LASTNAME', 'lastName')}`.trim();
        row.insertCell().textContent = name;
        row.insertCell().textContent = field(staff, 'EMAIL', 'email');
        row.insertCell().textContent = field(staff, 'PHONENUMBER', 'phone');
        row.insertCell().textContent = field(staff, 'SHIFT_HOURS', 'shiftHours') || 'Not assigned';
        const actions = row.insertCell();
        actions.style.verticalAlign = 'middle';
        actions.style.minWidth = '120px';

        const btnGroup = document.createElement('div');
        btnGroup.style.display = 'flex';
        btnGroup.style.flexDirection = 'column';
        btnGroup.style.gap = '0.4rem';
        btnGroup.style.width = '100%';
        btnGroup.style.maxWidth = '130px';

        const editBtn = document.createElement('button');
        editBtn.type = 'button'; 
        editBtn.className = 'btn-primary'; 
        editBtn.textContent = 'Edit';
        editBtn.style.width = '100%';
        editBtn.style.padding = '0.45rem 0.75rem';
        editBtn.style.textAlign = 'center';
        editBtn.style.fontSize = '0.875rem';
        editBtn.style.fontWeight = '600';
        editBtn.style.boxSizing = 'border-box';

        editBtn.addEventListener('click', () => {
          form.dataset.staffId = field(staff, 'STAFF_ID', 'staffId');
          document.getElementById('edit-original-email').value = field(staff, 'EMAIL', 'email');
          document.getElementById('edit-staff-name').value = `${field(staff, 'FIRSTNAME', 'firstName')} ${field(staff, 'LASTNAME', 'lastName')}`.trim();
          document.getElementById('edit-staff-phone').value = field(staff, 'PHONENUMBER', 'phone');
          document.getElementById('edit-staff-email').value = field(staff, 'EMAIL', 'email');
          const shiftInput = document.getElementById('edit-staff-shift');
          if (shiftInput) shiftInput.value = field(staff, 'SHIFT_HOURS', 'shiftHours') || 'Not assigned';
          const passwordInput = document.getElementById('edit-staff-password');
          if (passwordInput) { passwordInput.value = ''; passwordInput.required = false; passwordInput.placeholder = 'Leave blank to keep password'; }
          document.getElementById('edit-form-title').textContent = `Editing ${name}`;
          container.style.display = 'block'; container.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });

        const deleteBtn = document.createElement('button');
        deleteBtn.type = 'button';
        deleteBtn.className = 'btn-danger';
        deleteBtn.textContent = 'Delete';
        deleteBtn.style.width = '100%';
        deleteBtn.style.backgroundColor = '#dc2626';
        deleteBtn.style.color = '#ffffff';
        deleteBtn.style.border = 'none';
        deleteBtn.style.padding = '0.45rem 0.75rem';
        deleteBtn.style.borderRadius = '6px';
        deleteBtn.style.cursor = 'pointer';
        deleteBtn.style.fontSize = '0.875rem';
        deleteBtn.style.fontWeight = '600';
        deleteBtn.style.textAlign = 'center';
        deleteBtn.style.boxSizing = 'border-box';

        deleteBtn.addEventListener('click', async () => {
          const staffId = field(staff, 'STAFF_ID', 'staffId');
          const staffEmail = field(staff, 'EMAIL', 'email');
          const confirmed = window.confirm(
            `Confirm Staff Account Removal\n\nAre you sure you want to permanently delete the profile for "${name}" (${staffEmail})?\n\nOnce confirmed, their credentials and records will be removed from the database so they cannot log in again.`
          );
          if (!confirmed) return;

          deleteBtn.disabled = true;
          deleteBtn.textContent = 'Deleting…';
          try {
            const res = await api(`/api/staff/${encodeURIComponent(staffId)}`, {
              method: 'DELETE'
            });
            alert(res.message || `Staff member "${name}" has been permanently removed from the database.`);
            if (form.dataset.staffId === String(staffId)) {
              closeForm();
            }
            await load();
          } catch (error) {
            alert(`Could not delete staff member: ${error.message}`);
            deleteBtn.disabled = false;
            deleteBtn.textContent = 'Delete';
          }
        });

        btnGroup.appendChild(editBtn);
        btnGroup.appendChild(deleteBtn);
        actions.appendChild(btnGroup);
      });
    }
    async function load() {
      tableBody.innerHTML = '<tr><td colspan="5">Loading staff from SQL Server…</td></tr>';
      try {
        const query = facilityId ? `?facilityId=${encodeURIComponent(facilityId)}` : '';
        const result = await api(`/api/staff${query}`);
        staffRecords = result.staff || [];
        render();
      } catch (error) {
        tableBody.innerHTML = '';
        const row = tableBody.insertRow(); const cell = row.insertCell(); cell.colSpan = 5;
        cell.textContent = `Could not load staff from database: ${error.message}`;
      }
    }
    function closeForm() { container.style.display = 'none'; form.reset(); delete form.dataset.staffId; }
    document.getElementById('btn-cancel-top')?.addEventListener('click', closeForm);
    document.getElementById('btn-cancel-bottom')?.addEventListener('click', closeForm);
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      const button = form.querySelector('button[type="submit"]');
      if (button) { button.disabled = true; button.textContent = 'Saving…'; }
      try {
        const parts = document.getElementById('edit-staff-name').value.trim().split(/\s+/);
        if (parts.length < 2) throw new Error('Enter first name and surname.');
        await api(`/api/staff/${encodeURIComponent(form.dataset.staffId)}`, {
          method: 'PUT',
          body: JSON.stringify({
            firstName: parts[0], lastName: parts.slice(1).join(' '),
            email: document.getElementById('edit-staff-email').value.trim(),
            phone: document.getElementById('edit-staff-phone').value.trim(),
            password: document.getElementById('edit-staff-password').value,
            shiftHours: document.getElementById('edit-staff-shift')?.value || 'Not assigned'
          })
        });
        alert('Staff details updated in the SQL Server PERSONS table.');
        closeForm(); await load();
      } catch (error) { alert(`Could not update staff: ${error.message}`); }
      finally { if (button) { button.disabled = false; button.textContent = 'Save Changes'; } }
    });
    load();
  }

function initializeAttendanceExports() {
  const tbody = document.getElementById('attendance-tbody');
  const pdfButton = document.getElementById('btn-pdf');
  const wordButton = document.getElementById('btn-word');
  const csvButton = document.getElementById('btn-csv');
  if (!tbody || (!pdfButton && !wordButton && !csvButton)) return;

  const startInput = document.getElementById('start-date');
  const endInput = document.getElementById('end-date');
  const groupInput = document.getElementById('visitor-group');
  const timeframeInput = document.getElementById('timeframe');
  const headers = ['Date', 'Time', 'Member Name', 'Member Type', 'Group Name', 'Booking Status', 'Staff ID'];
  const rows = Array.from(tbody.querySelectorAll('tr')).map((tr) => ({
    tr,
    cells: Array.from(tr.querySelectorAll('td')).map((td) => td.innerText.trim()),
  })).filter((r) => r.cells.length >= 6);

  const dateValue = (text) => {
    if (!text) return null;
    const parts = text.split(/[/-]/);
    if (parts.length === 3) {
      const [a, b, c] = parts;
      return a.length === 4 ? new Date(+a, +b - 1, +c) : new Date(+c, +a - 1, +b);
    }
    const parsed = new Date(text);
    return Number.isNaN(parsed.getTime()) ? null : parsed;
  };
  const filteredRows = () => {
    const start = startInput?.value ? new Date(`${startInput.value}T00:00:00`) : null;
    const end = endInput?.value ? new Date(`${endInput.value}T23:59:59`) : null;
    const group = groupInput?.value || 'All Visitors';
    return rows.filter(({ cells }) => {
      const d = dateValue(cells[0]);
      if (start && d && d < start) return false;
      if (end && d && d > end) return false;
      if (group !== 'All Visitors' && (cells[3] || '').toLowerCase() !== group.toLowerCase()) return false;
      return true;
    });
  };
  const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  const filenameBase = () => `Aqualon_Attendance_${startInput?.value || 'all'}_to_${endInput?.value || 'all'}`;
  const download = (blob, filename) => {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  const getExportData = () => {
    const result = filteredRows();
    if (!result.length) {
      window.alert('No attendance rows match the selected filters.');
      return null;
    }
    return result;
  };

  const refreshTable = () => {
    const active = new Set(filteredRows().map((r) => r.tr));
    rows.forEach(({ tr }) => { tr.hidden = !active.has(tr); });
    let empty = document.getElementById('attendance-export-empty');
    if (!active.size && !empty) {
      empty = document.createElement('tr');
      empty.id = 'attendance-export-empty';
      empty.innerHTML = '<td colspan="7" style="text-align:center;padding:16px">No attendance rows match the selected filters.</td>';
      tbody.appendChild(empty);
    } else if (active.size && empty) empty.remove();
  };
  [startInput, endInput, groupInput, timeframeInput].filter(Boolean).forEach((el) => el.addEventListener('change', refreshTable));

  if (csvButton) csvButton.addEventListener('click', () => {
    const data = getExportData();
    if (!data) return;
    const quote = (v) => {
      let value = String(v ?? '');
      if (/^[=+@\-]/.test(value)) value = `'${value}`;
      return `"${value.replace(/"/g, '""')}"`;
    };
    const csv = '\uFEFF' + [headers, ...data.map((r) => headers.map((_, i) => r.cells[i] || ''))].map((r) => r.map(quote).join(',')).join('\r\n');
    download(new Blob([csv], { type: 'text/csv;charset=utf-8' }), `${filenameBase()}.csv`);
  });

  if (wordButton) wordButton.addEventListener('click', () => {
    const data = getExportData();
    if (!data) return;
    const tableRows = data.map(({ cells }) => `<tr>${headers.map((_, i) => `<td>${escapeHtml(cells[i] || '')}</td>`).join('')}</tr>`).join('');
    const doc = `<!doctype html><html><head><meta charset="utf-8"><title>Aqualon Attendance Report</title><style>body{font-family:Arial,sans-serif;color:#14213d}h1{color:#0369a1}table{border-collapse:collapse;width:100%}th,td{border:1px solid #94a3b8;padding:7px;text-align:left}th{background:#e0f2fe}</style></head><body><h1>Aqualon Facility Attendance Report</h1><p>Date range: ${escapeHtml(startInput?.value || 'All')} to ${escapeHtml(endInput?.value || 'All')} | Visitor group: ${escapeHtml(groupInput?.value || 'All Visitors')}</p><p>Timeframe: ${escapeHtml(timeframeInput?.value || 'Any')} | Records: ${data.length}</p><table><thead><tr>${headers.map((h) => `<th>${h}</th>`).join('')}</tr></thead><tbody>${tableRows}</tbody></table></body></html>`;
    download(new Blob(['\uFEFF', doc], { type: 'application/msword;charset=utf-8' }), `${filenameBase()}.doc`);
  });

  if (pdfButton) pdfButton.addEventListener('click', () => {
    const data = getExportData();
    if (!data) return;

    const ascii = (value) => String(value ?? '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^\x20-\x7E]/g, '?');
    const pdfText = (value) => ascii(value).replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');
    const colWidths = [58, 52, 126, 70, 118, 104, 90];
    const pageRows = 24;
    const pages = [];
    for (let i = 0; i < data.length; i += pageRows) pages.push(data.slice(i, i + pageRows));
    const objects = [];
    objects[1] = '<< /Type /Catalog /Pages 2 0 R >>';
    objects[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>';
    const pageRefs = [];
    const pageWidth = 792;
    const marginX = 36;
    const tableWidth = colWidths.reduce((a, b) => a + b, 0);
    const drawText = (text, x, y, size, color = '0 0 0') => `BT /F1 ${size} Tf ${color} rg ${x} ${y} Td (${pdfText(text)}) Tj ET\n`;

    pages.forEach((pageRowsData, pageIndex) => {
      const pageObjectNum = 4 + pageIndex * 2;
      const contentObjectNum = pageObjectNum + 1;
      pageRefs.push(`${pageObjectNum} 0 R`);
      let stream = '';
      stream += drawText('Aqualon Facility Attendance Report', marginX, 565, 17, '0.02 0.41 0.65');
      stream += drawText(`Date range: ${startInput?.value || 'All'} to ${endInput?.value || 'All'} | Group: ${groupInput?.value || 'All Visitors'}`, marginX, 545, 9, '0.2 0.25 0.3');
      stream += drawText(`Timeframe: ${timeframeInput?.value || 'Any'} | Total records: ${data.length} | Page ${pageIndex + 1} of ${pages.length}`, marginX, 530, 9, '0.2 0.25 0.3');
      const headerY = 505;
      let x = marginX;
      stream += '0.88 0.94 0.98 rg\n';
      stream += `${marginX} ${headerY - 5} ${tableWidth} 22 re f\n`;
      headers.forEach((h, i) => {
        stream += drawText(h, x + 4, headerY + 3, 7, '0.05 0.2 0.3');
        x += colWidths[i];
      });
      pageRowsData.forEach(({ cells }, rowIndex) => {
        const y = headerY - 19 - rowIndex * 18;
        stream += '0.75 0.8 0.86 RG 0.5 w\n';
        stream += `${marginX} ${y - 5} m ${marginX + tableWidth} ${y - 5} l S\n`;
        let cellX = marginX;
        headers.forEach((_, colIndex) => {
          const maxChars = Math.max(6, Math.floor((colWidths[colIndex] - 8) / 4.2));
          const text = ascii(cells[colIndex] || '');
          const display = text.length > maxChars ? `${text.slice(0, maxChars - 1)}…` : text;
          stream += drawText(display, cellX + 4, y, 7, '0.08 0.12 0.18');
          cellX += colWidths[colIndex];
        });
      });
      const streamLength = new TextEncoder().encode(stream).length;
      objects[pageObjectNum] = `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageWidth} 612] /Resources << /Font << /F1 3 0 R >> >> /Contents ${contentObjectNum} 0 R >>`;
      objects[contentObjectNum] = `<< /Length ${streamLength} >>\nstream\n${stream}endstream`;
    });
    objects[2] = `<< /Type /Pages /Kids [${pageRefs.join(' ')}] /Count ${pages.length} >>`;
    let pdf = '%PDF-1.4\n';
    const offsets = [0];
    for (let i = 1; i < objects.length; i++) {
      offsets[i] = new TextEncoder().encode(pdf).length;
      pdf += `${i} 0 obj\n${objects[i]}\nendobj\n`;
    }
    const xrefOffset = new TextEncoder().encode(pdf).length;
    pdf += `xref\n0 ${objects.length}\n0000000000 65535 f \n`;
    for (let i = 1; i < objects.length; i++) pdf += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
    pdf += `trailer\n<< /Size ${objects.length} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;
    download(new Blob([pdf], { type: 'application/pdf' }), `${filenameBase()}.pdf`);
  });
}


  
  function initializeItAdminDashboard(user) {
    if (currentPage() !== 'itadmin-dashboard.html') return;
    const API_BASE = (window.AQUALON_API_BASE || 'http://localhost:3000').replace(/\/$/, '');

    const staffEl = document.getElementById('dash-active-staff');
    const membersEl = document.getElementById('dash-facility-members');
    const incidentsEl = document.getElementById('dash-pending-incidents');
    const maintEl = document.getElementById('dash-open-maintenance');
    const alertsContainer = document.getElementById('dash-alerts-container');
    const trafficBars = document.getElementById('dash-traffic-bars');

    fetch(`${API_BASE}/api/admin/dashboard-stats`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (!data) return;
        if (staffEl) staffEl.textContent = data.activeStaff ?? '0';
        if (membersEl) membersEl.textContent = Number(data.facilityMembers || 0).toLocaleString();
        if (incidentsEl) incidentsEl.textContent = data.pendingIncidents ?? '0';
        if (maintEl) maintEl.textContent = data.openMaintenance ?? '0';

        if (alertsContainer && Array.isArray(data.alerts) && data.alerts.length > 0) {
          alertsContainer.innerHTML = '';
          data.alerts.forEach((alt) => {
            const item = document.createElement('div');
            item.className = 'alert-item';
            const dotClass = alt.type === 'critical' ? 'dot critical' : (alt.type === 'warning' ? 'dot warning' : 'dot notice');
            item.innerHTML = `
              <span class="${dotClass}"></span>
              <div class="alert-details">
                <h4>${alt.title}</h4>
                <p>${alt.description || ''}</p>
                <span class="alert-meta">${alt.meta || 'Active'}</span>
              </div>
            `;
            alertsContainer.appendChild(item);
          });
        }

        if (trafficBars && Array.isArray(data.traffic) && data.traffic.length > 0) {
          trafficBars.innerHTML = '';
          data.traffic.forEach((t) => {
            const bar = document.createElement('div');
            bar.className = 'bar';
            bar.style.height = `${t.pct}%`;
            bar.title = `${t.day}: ${t.count} bookings`;
            bar.innerHTML = `<span>${t.day}</span>`;
            trafficBars.appendChild(bar);
          });
        }
      })
      .catch((err) => console.warn('[Aqualon Dashboard] Stats fetch:', err.message));
  }

  const activePage = currentPage();
  const user = getCurrentUser();

  if (user) {
    initializeAttendanceExports();
    initializeAdminStaffPages(user);
    setFacilityCard(user);
    renderBookingHistory(user);
    renderUpcomingBookings(user);
    initializeAnnouncementWorkflow(user);
    initializeIncidentWorkflow(user);
    initializeMaintenanceWorkflow(user);
    initializeProfilePicture(user);
    initializeMemberSettings(user);
    initializeStaffSettings(user);
    initializeStaffDashboard(user);
    initializeItAdminDashboard(user);
    initializeItAdminSettings(user);

    const normalizedRole = normalizeRole(user.role);
    const allowed = allowedPages[normalizedRole];
    if (allowed && !allowed.includes(activePage)) {
      window.location.href = roleDashboardMap[normalizedRole] || 'login.html';
      return;
    }
  } else if (activePage !== 'login.html' && activePage !== 'signup.html' && activePage !== 'forgot-password.html') {
    window.location.href = 'login.html';
  }
};
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeAqualonApp, { once: true });
} else {
  initializeAqualonApp();
}