const initializeAqualonBooking = () => {
  const facilitySelect = document.getElementById('facility');
  const activitySelect = document.getElementById('activity');
  const timeSlotSelect = document.getElementById('time-slot');
  const guestsInput = document.getElementById('guests');
  const bookingDateInput = document.getElementById('booking-date');
  const form = document.getElementById('booking-form');
  const dynamicSection = document.getElementById('facility-dynamic-section');
  const alertBox = document.getElementById('booking-alert');
  const paymentModal = document.getElementById('booking-payment-modal');
  const modalTotal = document.getElementById('payment-total');
  const modalReference = document.getElementById('payment-reference');
  const modalClose = document.getElementById('close-payment-modal');

  const stanmorePrices = {
    '1 on 1 (individual) on request': 150,
    'Baby & Parent per month (1 per week)': 400,
    'Baby & Parent per month (2 per week)': 800,
    'Baby & Coach (20 mins lesson)': 120,
    'Learn to Swim (LTS) per month (1 per week)': 420,
    'Learn to Swim (LTS) per month (2 per week)': 840,
    'Stroke Correction (1 per week)': 420,
    'Stroke Correction per month (2 per week)': 840,
    'Social swimming': 300,
    'Adult learn to swim (1 per week)': 450,
    'Adult learn to swim (2 per week)': 900,
    'Water Polo': 420,
    'Artistic Swimming (synchro)': 420
  };

  const joanPrices = {
    'Daily Child / Pensioner': 20,
    'Daily Adult': 22,
    'Season Child / Pensioner': 397,
    'Season Adult': 796,
    'Season Coach': 796,
    'Season Spectator': 397,
    'Half Season Spectator': 199,
    'Half Season Child / Pensioner': 199,
    'Half Season Adult': 398,
    'Group School Children (31–50)': 1192,
    'Group School Children (51–200)': 1819,
    'Group School Children (201–500)': 3061,
    'Group School Children (501 and more)': 3625
  };

  const fieldVisibility = {
    activity: activitySelect?.closest('.form-group') || null,
    time: timeSlotSelect?.closest('.form-group') || null,
    guests: guestsInput?.closest('.form-group') || null
  };

  function showAlert(message, type = 'info') {
    if (!alertBox) return;

    alertBox.textContent = message;
    alertBox.className = 'alert-box';
    alertBox.classList.add(type === 'error' ? 'alert-error' : type === 'success' ? 'alert-success' : 'alert-info');
    alertBox.style.display = 'block';
  }

  function clearAlert() {
    if (!alertBox) return;
    alertBox.style.display = 'none';
    alertBox.textContent = '';
    alertBox.className = 'alert-box';
  }

  function toggleGenericBookingFields(show) {
    const controls = [
      { wrapper: fieldVisibility.activity, control: activitySelect },
      { wrapper: fieldVisibility.time, control: timeSlotSelect },
      { wrapper: fieldVisibility.guests, control: guestsInput }
    ];

    controls.forEach(({ wrapper, control }) => {
      if (wrapper) {
        wrapper.style.display = show ? 'flex' : 'none';
      }

      if (control) {
        control.style.display = show ? '' : 'none';
        control.disabled = !show;
      }
    });
  }

  function getSelectedBookingActivityLabel() {
    const facility = facilitySelect.value;

    if (facility === 'stanmore') {
      return document.querySelector('select[name="stanmoreOption"]')?.value || 'Stanmore booking';
    }

    if (facility === 'joan-harrison') {
      return document.querySelector('select[name="joanPackage"]')?.value || 'Joan Harrison booking';
    }

    if (facility === 'orient-beach') {
      return document.querySelector('select[name="orientCategory"]')?.value || activitySelect.value || 'Orient Beach booking';
    }

    return activitySelect.value || 'General booking';
  }

  function setGenericActivityOptions(facility) {
    if (!activitySelect) return;

    let options = [];
    if (facility === 'stanmore') {
      options = [
        'Baby & Parent per month (1 per week)',
        'Baby & Parent per month (2 per week)',
        'Baby & Coach (20 mins lesson)',
        'Learn to Swim (LTS) per month (1 per week)',
        'Learn to Swim (LTS) per month (2 per week)',
        'Stroke Correction (1 per week)',
        'Stroke Correction per month (2 per week)',
        'Social swimming',
        'Adult learn to swim (1 per week)',
        'Adult learn to swim (2 per week)',
        'Water Polo',
        'Artistic Swimming (synchro)'
      ];
    }

    if (facility === 'joan-harrison') {
      options = [
        'Daily Child / Pensioner',
        'Daily Adult',
        'Season Child / Pensioner',
        'Season Adult',
        'Season Coach',
        'Season Spectator',
        'Half Season Spectator',
        'Half Season Child / Pensioner',
        'Half Season Adult',
        'Group School Children (31–50)',
        'Group School Children (51–200)',
        'Group School Children (201–500)',
        'Group School Children (501 and more)'
      ];
    }

    if (facility === 'orient-beach') {
      options = ['Community Member', 'Tourist', 'Wedding Event'];
    }

    activitySelect.innerHTML = '<option value="" selected disabled>Please choose a facility first...</option>';
    options.forEach((optionText) => {
      const option = document.createElement('option');
      option.value = optionText;
      option.textContent = optionText;
      activitySelect.appendChild(option);
    });

    activitySelect.disabled = !options.length;
  }

  function calculateAge(dateString) {
    if (!dateString) return null;
    const birthDate = new Date(dateString);
    if (Number.isNaN(birthDate.getTime())) return null;

    const now = new Date();
    let age = now.getFullYear() - birthDate.getFullYear();
    const monthDiff = now.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && now.getDate() < birthDate.getDate())) {
      age -= 1;
    }
    return age;
  }

  function getChildAgeFromForm(childForm) {
    const dob = childForm.querySelector('input[name="childDob"]').value;
    return calculateAge(dob);
  }

  function updateGuardianRequirements() {
    const childForms = dynamicSection.querySelectorAll('.child-form');
    const hasMinor = Array.from(childForms).some((childForm) => {
      const age = getChildAgeFromForm(childForm);
      return age !== null && age < 18;
    });

    const guardianGroups = dynamicSection.querySelectorAll('.guardian-required');
    guardianGroups.forEach((group) => {
      const toggleField = group.querySelector('input, select, textarea');
      if (!toggleField) return;
      toggleField.required = hasMinor;
      group.style.display = hasMinor ? 'flex' : 'none';
    });
  }

  function addChildForm() {
    const childForms = dynamicSection.querySelectorAll('.child-form');
    if (childForms.length >= 4) {
      showAlert('You can register up to 4 children.', 'info');
      return;
    }

    const wrapper = document.createElement('div');
    wrapper.className = 'child-form';
    const index = childForms.length + 1;
    wrapper.innerHTML = `
      <div class="child-form-header">
        <h5>Child ${index}</h5>
      </div>
      <div class="form-grid">
        <div class="form-group">
          <label>Name</label>
          <input type="text" name="childName" placeholder="Child name" required>
        </div>
        <div class="form-group">
          <label>Surname</label>
          <input type="text" name="childSurname" placeholder="Child surname" required>
        </div>
        <div class="form-group">
          <label>Gender</label>
          <select name="childGender" required>
            <option value="">Select</option>
            <option value="M">M</option>
            <option value="F">F</option>
          </select>
        </div>
        <div class="form-group">
          <label>Date of Birth</label>
          <input type="date" name="childDob" required>
        </div>
      </div>
    `;

    const childHolder = dynamicSection.querySelector('#child-forms');
    childHolder.appendChild(wrapper);
    wrapper.querySelector('input[name="childDob"]').addEventListener('change', updateGuardianRequirements);
    updateGuardianRequirements();

    const addButton = dynamicSection.querySelector('#add-child-button');
    if (addButton) {
      addButton.disabled = childForms.length + 1 >= 4;
    }
  }

  function renderStanmoreFields() {
    dynamicSection.innerHTML = `
      <div class="facility-dynamic-panel">
        <h4>Parent / Primary Contact Information</h4>
        <div class="form-grid">
          <div class="form-group">
            <label>Parent Full Name</label>
            <input type="text" name="parentFullName" required>
          </div>
          <div class="form-group">
            <label>Address</label>
            <input type="text" name="parentAddress" required>
          </div>
          <div class="form-group">
            <label>Home Phone</label>
            <input type="tel" name="homePhone" required>
          </div>
          <div class="form-group">
            <label>Mother's Cell</label>
            <input type="tel" name="mothersCell" required>
          </div>
          <div class="form-group">
            <label>Father's Cell</label>
            <input type="tel" name="fathersCell" required>
          </div>
          <div class="form-group">
            <label>Emergency Contact</label>
            <input type="text" name="emergencyContact" required>
          </div>
          <div class="form-group">
            <label>School child is attending</label>
            <input type="text" name="schoolName" required>
          </div>
          <div class="form-group">
            <label>Notifiable medical conditions</label>
            <input type="text" name="medicalConditions" placeholder="None / details">
          </div>
        </div>

        <h4>Dynamic Children's Information Form</h4>
        <div id="child-forms"></div>
        <button type="button" id="add-child-button" class="btn-secondary">Add Child</button>

        <div class="guardian-required-group">
          <div class="form-group guardian-required">
            <label>Guardian Details</label>
            <input type="text" name="guardianDetails" placeholder="Guardian name and relationship">
          </div>
          <div class="form-group guardian-required">
            <label>Consent / Declaration</label>
            <textarea name="guardianConsent" rows="3" placeholder="Consent statement"></textarea>
          </div>
        </div>

        <div class="form-grid">
          <div class="form-group">
            <label>Preferred day and time</label>
            <select name="preferredLessonSlot" required>
              <option value="">Select slot</option>
              <option value="Monday 12:30 PM – 4:00 PM">Monday 12:30 PM – 4:00 PM</option>
              <option value="Tuesday 09:00 AM – 10:30 AM">Tuesday 09:00 AM – 10:30 AM</option>
              <option value="Tuesday 12:30 PM – 4:00 PM">Tuesday 12:30 PM – 4:00 PM</option>
              <option value="Wednesday 12:30 PM – 4:00 PM">Wednesday 12:30 PM – 4:00 PM</option>
              <option value="Thursday 09:00 AM – 10:30 AM">Thursday 09:00 AM – 10:30 AM</option>
              <option value="Thursday 12:30 PM – 4:00 PM">Thursday 12:30 PM – 4:00 PM</option>
              <option value="Friday 12:30 PM – 3:00 PM">Friday 12:30 PM – 3:00 PM</option>
              <option value="Saturday 08:00 AM – 11:00 AM">Saturday 08:00 AM – 11:00 AM</option>
            </select>
          </div>
          <div class="form-group">
            <label>Sessions per week</label>
            <select name="sessionsPerWeek" required>
              <option value="">Select</option>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
            </select>
          </div>
          <div class="form-group">
            <label>Payment option</label>
            <select name="paymentOption" required>
              <option value="">Select</option>
              <option value="Per Lesson">Per Lesson</option>
              <option value="Monthly">Monthly</option>
              <option value="Termly">Termly</option>
            </select>
          </div>
          <div class="form-group">
            <label>Swimming option</label>
            <select name="stanmoreOption" required>
              <option value="">Select</option>
              ${Object.keys(stanmorePrices).map((item) => `<option value="${item}">${item}</option>`).join('')}
            </select>
          </div>
        </div>

        <div class="checkbox-row">
          <input type="checkbox" id="stanmore-indemnity" name="indemnity" required>
          <label for="stanmore-indemnity">I agree to the indemnity and consent terms for this booking.</label>
        </div>
      </div>
    `;

    const addButton = dynamicSection.querySelector('#add-child-button');
    addButton.addEventListener('click', addChildForm);

    const firstChild = document.createElement('div');
    firstChild.className = 'child-form';
    firstChild.innerHTML = `
      <div class="child-form-header">
        <h5>Child 1</h5>
      </div>
      <div class="form-grid">
        <div class="form-group">
          <label>Name</label>
          <input type="text" name="childName" placeholder="Child name" required>
        </div>
        <div class="form-group">
          <label>Surname</label>
          <input type="text" name="childSurname" placeholder="Child surname" required>
        </div>
        <div class="form-group">
          <label>Gender</label>
          <select name="childGender" required>
            <option value="">Select</option>
            <option value="M">M</option>
            <option value="F">F</option>
          </select>
        </div>
        <div class="form-group">
          <label>Date of Birth</label>
          <input type="date" name="childDob" required>
        </div>
      </div>
    `;
    dynamicSection.querySelector('#child-forms').appendChild(firstChild);
    firstChild.querySelector('input[name="childDob"]').addEventListener('change', updateGuardianRequirements);

    updateGuardianRequirements();
    addButton.disabled = false;
  }

  function renderJoanFields() {
    dynamicSection.innerHTML = `
      <div class="facility-dynamic-panel">
        <h4>Facility-Specific Booking Flow</h4>
        <div class="pool-breakdown">
          <div class="pool-item"><strong>Water Polo Pool:</strong> Mostly private; reserved for members or polo events.</div>
          <div class="pool-item"><strong>Kiddies Pool:</strong> Shallow recreational pool for children and families.</div>
          <div class="pool-item"><strong>Diving Pools:</strong> Restricted/professional access only.</div>
          <div class="pool-item"><strong>Main Pool:</strong> Open for public recreational bookings, lane swimming and events.</div>
        </div>

        <div class="form-grid">
          <div class="form-group">
            <label>Booking Type</label>
            <select name="joanBookingType" required>
              <option value="">Select</option>
              <option value="General Access">General Access</option>
              <option value="Swim Gala / Event">Swim Gala / Event</option>
              <option value="Private Coaching">Private Coaching</option>
            </select>
          </div>
          <div class="form-group">
            <label>Pool Access</label>
            <select name="joanPool" required>
              <option value="">Select</option>
              <option value="Water Polo Pool">Water Polo Pool</option>
              <option value="Kiddies Pool">Kiddies Pool</option>
              <option value="Diving Pools">Diving Pools</option>
              <option value="Main Pool">Main Pool</option>
            </select>
          </div>
          <div class="form-group">
            <label>Confirm Guest Number</label>
            <input type="number" name="joanGuests" min="1" max="500" value="1" required>
          </div>
          <div class="form-group">
            <label>Category / Option</label>
            <select name="joanPackage" required>
              <option value="">Select</option>
              ${Object.entries(joanPrices).map(([label]) => `<option value="${label}">${label}</option>`).join('')}
            </select>
          </div>
        </div>
      </div>
    `;

    const guestInput = dynamicSection.querySelector('input[name="joanGuests"]');
    guestInput.addEventListener('input', () => {
      const guests = Number(guestInput.value || 0);
      if (guests >= 31) {
        showAlert('31+ guest booking has been flagged as a full facility closure and gala-level reservation.', 'info');
      } else {
        clearAlert();
      }
    });
  }

  function renderOrientFields() {
    dynamicSection.innerHTML = `
      <div class="facility-dynamic-panel">
        <h4>Orient Beach & Swimming Pools</h4>
        <div class="form-group">
          <label>Event Category</label>
          <select name="orientCategory" required>
            <option value="">Select</option>
            <option value="Community Member">Community Member</option>
            <option value="Tourist">Tourist</option>
            <option value="Wedding Host">Wedding Host</option>
          </select>
        </div>

        <div id="orient-wedding-fields" style="display:none;">
          <div class="form-grid">
            <div class="form-group">
              <label>Confirm Guest Number</label>
              <input type="number" name="weddingGuests" min="1" value="1" required>
            </div>
            <div class="form-group">
              <label>Attendee List Upload</label>
              <input type="file" name="weddingFile" accept=".pdf,.doc,.docx" required>
            </div>
          </div>
          <p class="helper-text">Wedding host bookings close the facility to public access after admin approval.</p>
        </div>
      </div>
    `;

    const orientCategory = dynamicSection.querySelector('select[name="orientCategory"]');
    const weddingFields = dynamicSection.querySelector('#orient-wedding-fields');
    weddingFields.querySelectorAll('input').forEach((input) => {
      input.required = false;
      input.disabled = true;
    });

    orientCategory.addEventListener('change', () => {
      const isWedding = orientCategory.value === 'Wedding Host';
      weddingFields.style.display = isWedding ? 'block' : 'none';
      const weddingInputs = weddingFields.querySelectorAll('input');
      weddingInputs.forEach((input) => {
        input.required = isWedding;
        input.disabled = !isWedding;
      });
      if (!isWedding) {
        toggleGenericBookingFields(true);
      } else {
        toggleGenericBookingFields(false);
      }
    });
  }

  function renderFacilitySpecificForm() {
    const facility = facilitySelect.value;
    clearAlert();

    if (!facility) {
      dynamicSection.innerHTML = '';
      toggleGenericBookingFields(true);
      return;
    }

    toggleGenericBookingFields(!(facility === 'stanmore' || facility === 'joan-harrison'));
    if (facility === 'stanmore') {
      toggleGenericBookingFields(false);
      renderStanmoreFields();
      setGenericActivityOptions('stanmore');
      activitySelect.disabled = true;
      return;
    }

    if (facility === 'joan-harrison') {
      toggleGenericBookingFields(false);
      renderJoanFields();
      setGenericActivityOptions('joan-harrison');
      activitySelect.disabled = true;
      return;
    }

    if (facility === 'orient-beach') {
      renderOrientFields();
      toggleGenericBookingFields(true);
      setGenericActivityOptions('orient-beach');
      activitySelect.disabled = false;
      return;
    }
  }

  function getSelectedActivityPrice() {
    const facility = facilitySelect.value;
    const selectedActivity = facility === 'stanmore'
      ? document.querySelector('select[name="stanmoreOption"]')?.value
      : facility === 'joan-harrison'
        ? document.querySelector('select[name="joanPackage"]')?.value
        : activitySelect.value;

    if (facility === 'stanmore') {
      return stanmorePrices[selectedActivity] || 0;
    }

    if (facility === 'joan-harrison') {
      return joanPrices[selectedActivity] || 0;
    }

    return 0;
  }

  function generateReference(surname) {
    const suffix = String((Math.floor(Math.random() * 9000) + 1000));
    return `AQL-BK-${suffix}-${String(surname || 'GUEST').slice(0, 10).toUpperCase()}`;
  }

  
  function getExistingBookings() {
    try {
      return JSON.parse(localStorage.getItem('aqualon_bookings') || '[]');
    } catch {
      return [];
    }
  }

  function checkDoubleBooking(newBooking, existingBookings) {
    const newDate = String(newBooking.date || '').trim();
    const newFacilityKey = String(newBooking.facilityKey || '').trim().toLowerCase();
    const newFacilityTitle = String(newBooking.facility || '').trim().toLowerCase();
    const newTimeSlot = String(newBooking.timeSlot || '').trim().toLowerCase();
    const newUserEmail = String(newBooking.userEmail || '').trim().toLowerCase();

    for (const b of existingBookings) {
      const bStatus = String(b.status || '').trim().toLowerCase();
      if (bStatus === 'cancelled' || bStatus === 'rejected') continue;

      const bDate = String(b.date || '').trim();
      if (bDate !== newDate) continue;

      const bUserEmail = String(b.userEmail || '').trim().toLowerCase();
      const bFacilityKey = String(b.facilityKey || '').trim().toLowerCase();
      const bFacilityTitle = String(b.facility || '').trim().toLowerCase();
      const bTimeSlot = String(b.timeSlot || '').trim().toLowerCase();

      // Rule 1: Same member and slot (or same member booking overlapping slot / same facility on same date)
      if (newUserEmail && bUserEmail === newUserEmail) {
        if (newTimeSlot && bTimeSlot && newTimeSlot === bTimeSlot) {
          return {
            conflict: true,
            reason: `Double booking prevented: You already have a confirmed booking (${b.id}) for this time slot (${newBooking.timeSlot || 'Session'}) on ${newDate}.`
          };
        }
        if (newFacilityKey === bFacilityKey || newFacilityTitle === bFacilityTitle) {
          if (!newTimeSlot || !bTimeSlot || newTimeSlot === bTimeSlot) {
            return {
              conflict: true,
              reason: `Double booking prevented: You already have an active booking (${b.id}) for ${newBooking.facility} on ${newDate}.`
            };
          }
        }
      }

      // Rule 2: Same facility, date, and time slot
      const isSameFacility = (newFacilityKey && bFacilityKey && newFacilityKey === bFacilityKey) ||
                             (newFacilityTitle && bFacilityTitle && newFacilityTitle === bFacilityTitle);

      if (isSameFacility) {
        // Full facility closure or wedding/gala event on that day
        if (b.closureFlag || String(b.activity || '').toLowerCase().includes('wedding') || String(b.activity || '').toLowerCase().includes('gala')) {
          return {
            conflict: true,
            reason: `Double booking prevented: ${newBooking.facility} is fully reserved for a private event on ${newDate}. No other bookings can be accepted for this date.`
          };
        }
        if (newBooking.closureFlag || String(newBooking.activity || '').toLowerCase().includes('wedding') || String(newBooking.activity || '').toLowerCase().includes('gala')) {
          return {
            conflict: true,
            reason: `Double booking prevented: Cannot book a full facility event on ${newDate} because active bookings already exist on this date.`
          };
        }

        // Exact same time slot clash
        if (newTimeSlot && bTimeSlot && newTimeSlot === bTimeSlot) {
          return {
            conflict: true,
            reason: `Double booking prevented: The time slot "${newBooking.timeSlot}" at ${newBooking.facility} on ${newDate} is already booked. Please choose another time slot or date.`
          };
        }
      }
    }

    return { conflict: false };
  }

  function validateCurrentSlotSelection() {
    const facility = facilitySelect ? facilitySelect.value : '';
    const bookingDate = bookingDateInput ? bookingDateInput.value : '';
    if (!facility || !bookingDate) return;

    const orientCategory = document.querySelector('select[name="orientCategory"]')?.value || '';
    const requestedTime = facility === 'stanmore'
      ? document.querySelector('select[name="preferredLessonSlot"]')?.value || ''
      : facility === 'joan-harrison' || orientCategory === 'Wedding Host'
        ? ''
        : timeSlotSelect?.value || '';

    const facilityTitle = facility === 'stanmore'
      ? 'Stanmore Aquatic Centre'
      : facility === 'joan-harrison'
        ? 'Joan Harrison Swimming Pools'
        : 'Orient Beach & Swimming Pools';

    const testBooking = {
      facility: facilityTitle,
      facilityKey: facility,
      date: bookingDate,
      timeSlot: requestedTime,
      userEmail: getSignedInMemberEmail()
    };

    const conflict = checkDoubleBooking(testBooking, getExistingBookings());
    const submitBtn = form?.querySelector('button[type="submit"]');

    if (conflict.conflict) {
      showAlert(conflict.reason, 'error');
      if (submitBtn) submitBtn.disabled = true;
    } else {
      clearAlert();
      if (submitBtn) submitBtn.disabled = false;
    }
  }

  function onBookingSubmit(event) {
    event.preventDefault();

    const facility = facilitySelect.value;
    const selectedActivity = getSelectedBookingActivityLabel();
    const facilityTitle = facility === 'stanmore'
      ? 'Stanmore Aquatic Centre'
      : facility === 'joan-harrison'
        ? 'Joan Harrison Swimming Pools'
        : 'Orient Beach & Swimming Pools';

    if (!facility) {
      showAlert('Please select a facility before confirming your booking.', 'error');
      return;
    }

    let total = 0;
    if (facility === 'stanmore') {
      total = getSelectedActivityPrice() * Math.max(1, dynamicSection.querySelectorAll('.child-form').length);
    } else if (facility === 'joan-harrison') {
      const guestCount = Number(document.querySelector('input[name="joanGuests"]')?.value || 1);
      const packageName = document.querySelector('select[name="joanPackage"]')?.value || 'Daily Adult';
      const isGroupPackage = packageName.startsWith('Group School Children');
      total = (joanPrices[packageName] || 0) * (isGroupPackage ? 1 : Math.max(1, guestCount));
      if (guestCount >= 31 || isGroupPackage || document.querySelector('select[name="joanBookingType"]')?.value === 'Swim Gala / Event') {
        showAlert('This booking exceeds the 31-guest rule and closes the full facility for the requested period.', 'info');
      }
    } else {
      total = getSelectedActivityPrice() || Number(guestsInput.value || 1) * 150;
    }

    const parentName = dynamicSection.querySelector('input[name="parentFullName"]')?.value || getSignedInMemberName();
    const surname = (parentName.split(/\s+/).pop() || 'Guest').toUpperCase();
    const bookingRef = generateReference(surname);
    const guestCount = getBookingGuestCount(facility);
    const bookingDate = bookingDateInput.value;
    const orientCategory = document.querySelector('select[name="orientCategory"]')?.value || '';
    const requestedTime = facility === 'stanmore'
      ? document.querySelector('select[name="preferredLessonSlot"]')?.value || ''
      : facility === 'joan-harrison' || orientCategory === 'Wedding Host'
        ? ''
        : timeSlotSelect.value || '';
    const duration = facility === 'stanmore'
      ? `${requestedTime}; ${document.querySelector('select[name="paymentOption"]')?.value || ''}`
      : requestedTime || (orientCategory === 'Wedding Host' ? 'Event booking' : 'Facility access');
    const status = facility === 'orient-beach' && orientCategory === 'Wedding Host' ? 'Pending Approval' : 'Active';
    const booking = {
      id: bookingRef,
      userEmail: getSignedInMemberEmail(),
      memberName: getSignedInMemberName(),
      facility: facilityTitle,
      facilityKey: facility,
      activity: selectedActivity,
      date: bookingDate,
      timeSlot: requestedTime,
      duration,
      guests: guestCount,
      total,
      status,
      createdAt: new Date().toISOString(),
      closureFlag: facility === 'joan-harrison' && (guestCount >= 31 || document.querySelector('select[name="joanPackage"]')?.value.startsWith('Group School Children') || document.querySelector('select[name="joanBookingType"]')?.value === 'Swim Gala / Event'),
      attendeeFileName: document.querySelector('input[name="weddingFile"]')?.files?.[0]?.name || ''
    };

    // Double booking verification (same facility, date & time slot + same member and slot)
    const existingBookings = getExistingBookings();
    const conflictCheck = checkDoubleBooking(booking, existingBookings);
    if (conflictCheck.conflict) {
      showAlert(conflictCheck.reason, 'error');
      const submitBtn = form ? form.querySelector('button[type="submit"]') : null;
      if (submitBtn) submitBtn.disabled = false;
      return;
    }

    saveMemberBooking(booking);

    if (paymentModal) {
      modalTotal.textContent = `R ${Number(total).toLocaleString('en-ZA')}`;
      modalReference.textContent = bookingRef;
      paymentModal.classList.remove('hidden');
      paymentModal.setAttribute('aria-hidden', 'false');
      document.getElementById('payment-facility').textContent = facilityTitle;
      document.getElementById('payment-activity').textContent = selectedActivity;
    }

    showAlert(`Booking submitted successfully for ${facilityTitle}. Payment instructions are ready below.`, 'success');
  }

  function getSignedInMember() {
    try {
      return JSON.parse(localStorage.getItem('aqualonUser') || 'null') || {};
    } catch (error) {
      return {};
    }
  }

  function getSignedInMemberEmail() {
    const user = getSignedInMember();
    return user.email || localStorage.getItem('aqualon_currentUser') || 'unknown-member';
  }

  function getSignedInMemberName() {
    const user = getSignedInMember();
    return user.name || user.fullName || 'Member';
  }

  function getBookingGuestCount(facility) {
    if (facility === 'stanmore') {
      return dynamicSection.querySelectorAll('.child-form').length || 1;
    }

    if (facility === 'joan-harrison') {
      return Number(document.querySelector('input[name="joanGuests"]')?.value || 1);
    }

    const weddingGuests = document.querySelector('input[name="weddingGuests"]');
    if (weddingGuests && !weddingGuests.disabled) {
      return Number(weddingGuests.value || 1);
    }
    return Number(guestsInput.value || 1);
  }

  function saveMemberBooking(booking) {
    const storageKey = 'aqualon_bookings';
    let bookings = [];
    try {
      bookings = JSON.parse(localStorage.getItem(storageKey) || '[]');
    } catch (error) {
      bookings = [];
    }
    bookings.push(booking);
    localStorage.setItem(storageKey, JSON.stringify(bookings));
  }

  if (facilitySelect) {
    facilitySelect.addEventListener('change', renderFacilitySpecificForm);
  }

  if (bookingDateInput) {
    const today = new Date();
    bookingDateInput.min = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    bookingDateInput.addEventListener('change', validateCurrentSlotSelection);
  }
  if (timeSlotSelect) {
    timeSlotSelect.addEventListener('change', validateCurrentSlotSelection);
  }

  if (form) {
    form.addEventListener('submit', onBookingSubmit);
  }

  if (modalClose) {
    modalClose.addEventListener('click', () => {
      paymentModal.classList.add('hidden');
      paymentModal.setAttribute('aria-hidden', 'true');
    });
  }

  if (paymentModal) {
    paymentModal.addEventListener('click', (event) => {
      if (event.target === paymentModal) {
        paymentModal.classList.add('hidden');
        paymentModal.setAttribute('aria-hidden', 'true');
      }
    });
  }

  setGenericActivityOptions(facilitySelect.value || '');
  toggleGenericBookingFields(true);
  renderFacilitySpecificForm();
};
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeAqualonBooking, { once: true });
} else {
  initializeAqualonBooking();
}