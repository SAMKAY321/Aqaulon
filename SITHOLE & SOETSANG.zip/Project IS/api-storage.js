/* Aqualon SQL persistence bridge. Loaded instead of direct script.js tags. */
(function () {
  'use strict';
  const API_BASE = (window.AQUALON_API_BASE || 'http://localhost:3000').replace(/\/$/, '');
  const KEYS = new Set([
    'aqualon_bookings',
    'aqualon_incidents',
    'aqualon_maintenance_reports',
    'aqualon_announcements',
    'aqualon_staff_shifts',
    'aqualon_system_preferences'
  ]);
  const nativeSetItem = Storage.prototype.setItem;
  const nativeRemoveItem = Storage.prototype.removeItem;
  let writeQueue = Promise.resolve();
  let ready = false;
  let apiOnline = false;
  const originalValues = new Map();

  function persist(key, rawValue) {
    if (!ready || !KEYS.has(key)) return;
    let value;
    try { value = JSON.parse(rawValue); } catch { value = rawValue; }
    writeQueue = writeQueue.then(async () => {
      const response = await fetch(`${API_BASE}/api/app-storage/${encodeURIComponent(key)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ value })
      });
      if (!response.ok) throw new Error(`SQL save failed for ${key}: HTTP ${response.status}`);
      window.dispatchEvent(new CustomEvent('aqualon:sql-saved', { detail: { key } }));
    }).catch((error) => {
      console.error('[Aqualon SQL] Data could not be saved. Keep the browser open and check the API connection.', error);
      window.dispatchEvent(new CustomEvent('aqualon:sql-save-error', { detail: { key, message: error.message } }));
    });
  }

  Storage.prototype.setItem = function (key, value) {
    nativeSetItem.call(this, key, value);
    if (this === window.localStorage) persist(String(key), String(value));
  };
  Storage.prototype.removeItem = function (key) {
    nativeRemoveItem.call(this, key);
    // Operational collections are represented as empty collections, not deleted rows.
    if (this === window.localStorage && KEYS.has(String(key))) persist(String(key), '[]');
  };

  async function bootstrap() {
    const legacyLocalValues = new Map();
    try {
      const response = await fetch(`${API_BASE}/api/app-storage`, { cache: 'no-store' });
      if (!response.ok) throw new Error(`API returned HTTP ${response.status}`);
      const result = await response.json();
      const data = result && result.data ? result.data : {};
      for (const key of KEYS) {
        if (Object.prototype.hasOwnProperty.call(data, key)) {
          nativeSetItem.call(window.localStorage, key, JSON.stringify(data[key]));
        } else {
          const existing = window.localStorage.getItem(key);
          if (existing !== null) legacyLocalValues.set(key, existing);
        }
      }
      apiOnline = true;
    } catch (error) {
      console.error('[Aqualon SQL] API unavailable. The app will open in local-only mode; changes will NOT be saved to SQL Server.', error);
      apiOnline = false;
    }
    ready = true;
    // First-run migration: if SQL has no row for a collection, seed it from this browser's existing data.
    if (apiOnline) {
      for (const [key, rawValue] of legacyLocalValues) persist(key, rawValue);
    }
    window.AQUALON_SQL_STATUS = { online: apiOnline, apiBase: API_BASE };
    const status = document.createElement('div');
    status.id = 'aqualon-sql-status';
    status.textContent = apiOnline ? 'Database connected' : 'Database offline — changes may not sync';
    status.style.cssText = `position:fixed;right:12px;bottom:12px;z-index:99999;padding:7px 11px;border-radius:8px;font:12px/1.4 system-ui,sans-serif;color:white;background:${apiOnline ? '#166534' : '#9a3412'};box-shadow:0 2px 8px #0002;`;
    document.body.appendChild(status);
    if (apiOnline) {
      window.addEventListener('aqualon:sql-save-error', () => {
        status.textContent = 'Database save failed — check API/SQL Server';
        status.style.background = '#991b1b';
      });
      window.addEventListener('aqualon:sql-saved', () => {
        status.textContent = 'Database connected · saved';
        status.style.background = '#166534';
      });
    }
    loadScript('script.js', () => {
      if (location.pathname.toLowerCase().endsWith('/booking.html') || location.pathname.toLowerCase().endsWith('booking.html')) {
        loadScript('booking.js');
      }
    });
  }
  function loadScript(src, onload) {
    const script = document.createElement('script');
    script.src = src;
    script.onload = () => { if (onload) onload(); };
    script.onerror = () => console.error(`[Aqualon] Could not load ${src}`);
    document.body.appendChild(script);
  }
  bootstrap();
})();