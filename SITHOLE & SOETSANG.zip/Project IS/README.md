# Aqualon Project IS — Revised ERD + SQL Server

## Architecture
- `Aqualon_SQLServer_Schema.sql` creates the Revised ERD entities in SQL Server, including `PERSONS`, `CUSTOMERS`, `STAFF`, `ITADMINS`, `SWIMMING_FACILITIES`, `BOOKINGS`, `INCIDENTS`, and `MAINTENANCE_LOGS`.
- `PERSON_AUTH` is a support table for hashed passwords and expiring, one-use password-reset tokens. It keeps credentials separate from `PERSONS`.
- `AppStorage` temporarily persists operational collections used by the existing frontend. Bookings and registered-user incidents are mirrored into ERD tables. Staff-authored maintenance logs are mirrored to `MAINTENANCE_LOGS`; member-originated maintenance requests remain in `AppStorage` until staff assignment because the ERD defines `MAINTENANCE_LOGS.STAFF_ID`. Announcements and staff shifts remain in `AppStorage` because the supplied ERD does not define those entities.
- `server.js` exposes registration, login, forgot-password and reset-password API endpoints.

## Important before running
Back up the database first. The schema adds missing ERD/app support tables and some integration columns to existing ERD tables, but it does not automatically migrate old `dbo.Users` records or old browser demo accounts into the ERD model. New member registrations are stored in `PERSONS`, `PERSON_AUTH`, and `CUSTOMERS`.

## Setup
1. In SSMS, open `Aqualon_SQLServer_Schema.sql` and execute it against the SQL Server instance. It creates/uses a database named `Aqualon`; change the `USE` database if your existing database has another name.
2. Install Node.js LTS.
3. Copy `.env.example` to `.env`. Fill in your actual SQL Server host, database, SQL login and password. Do not share or commit `.env`.
4. Copy `.env.example` to `.env`. If using email reset links, configure the SMTP variables; otherwise development mode shows a reset link in the browser.
5. In a terminal in this folder run `npm install` and `npm start`.
6. Verify `http://localhost:3000/api/health` returns `ok: true`.
7. Open `login.html` through VS Code Live Server at `http://127.0.0.1:5500/login.html`, not as a `file://` URL.

## Register/login/password reset
- Signup is public member registration only. It creates a `PERSONS` row with `P_TYPE='C'`, a `PERSON_AUTH` password hash, and a `CUSTOMERS` row.
- Login checks email or username and the selected role against SQL Server. Staff and IT Admin accounts must be created by an authorized administrator; public signup cannot assign privileged roles.
- Forgot password stores a SHA-256 hash of a random token with a 30-minute expiry. The reset token is single-use. Configure SMTP for real email delivery. In development only, the API returns a reset URL that the page displays.
- The existing legacy demo credentials are not automatically created in SQL Server and should not be expected to work until accounts are provisioned.

## SQL validation queries
```sql
SELECT p.PERSON_ID,p.FIRSTNAME,p.LASTNAME,p.EMAIL,p.USERNAME,p.P_TYPE,c.CUSTOMER_ID
FROM dbo.PERSONS p LEFT JOIN dbo.CUSTOMERS c ON c.PERSON_ID=p.PERSON_ID
ORDER BY p.PERSON_ID DESC;

SELECT TOP (20) * FROM dbo.BOOKINGS ORDER BY CREATED_AT DESC;
SELECT TOP (20) * FROM dbo.INCIDENTS ORDER BY SUBMITTED_AT DESC;
SELECT TOP (20) * FROM dbo.MAINTENANCE_LOGS ORDER BY SUBMITTED_AT DESC;
```

## Security / limitations
This is a local development integration. Do not expose it publicly without adding authenticated server sessions or tokens, role/facility authorization on every data endpoint, rate limiting for password-reset requests, HTTPS, and appropriate email verification. `AppStorage` endpoints are currently development-only and accept whole frontend collections; do not deploy them as-is for production or real personal data. The ERD does not define announcements or staff shifts, so those remain in `AppStorage` until the ERD is revised to include them.
