-- ==========================================================
-- AQUALON DATA SEEDING SCRIPT (3 Rows Per Table)
-- ==========================================================

-- 1. CITIES
INSERT INTO CITIES (CNAME) VALUES 
('East London'), 
('Gqeberha'), 
('Mthatha');

-- 2. SUBURBS
INSERT INTO SUBURBS (SNAME, CITY_ID) VALUES 
('Nahoon', 1), 
('Quigney', 1), 
('Beacon Bay', 1);

-- 3. SWIMMING_FACILITIES
INSERT INTO SWIMMING_FACILITIES (FNAME, SUBURB_ID, STREETNAME) VALUES 
('Nahoon Swimming Pool', 1, '12 Beach Road'),
('Orient Beach Pool', 2, '45 Esplanade'),
('Joan Harrison Complex', 3, '89 Frere Road');

-- 4. TIMES (Opening Hour MUST be before Closing Hour)
INSERT INTO TIMES (FACILITY_ID, DAY_CATEGORY, OPENING_HOUR, CLOSING_HOUR) VALUES 
(1, 'Weekday', '08:00:00', '18:00:00'),
(2, 'Weekend', '09:00:00', '17:00:00'),
(3, 'Public Holiday', '10:00:00', '15:00:00');

-- 5. DAILY_CAPACITY (Total Booked MUST be >= 0)
INSERT INTO DAILY_CAPACITY (FACILITY_ID, TOTAL_BOOKED, CALENDAR_DATE) VALUES 
(1, 15, '2026-11-01'),
(2, 45, '2026-11-01'),
(3, 10, '2026-11-02');

-- 6. BOOKING_TYPES
INSERT INTO BOOKING_TYPES (BTNAME) VALUES 
('Daily Adult'), 
('School Children Group (<=50)'), 
('Swimming Lessons (Per Month)');

-- 7. PRICE
INSERT INTO PRICE (PRICE_LIST, BTID) VALUES 
('R 20.00', 1), 
('R 1192.00', 2), 
('R 420.00', 3);

-- 8. SWIMMING_FACILITIES_BOOKINGS_TYPES (Junction Table)
INSERT INTO SWIMMING_FACILITIES_BOOKINGS_TYPES (FACILITY_ID, BTID) VALUES 
(1, 1), 
(2, 2), 
(3, 3);

-- 9. PERSONS (Emails MUST have @, P_TYPE MUST match constraints)
-- Inserting 3 Staff, 3 Admins, 3 Customers, and 3 Dependents
INSERT INTO PERSONS (FIRSTNAME, LASTNAME, EMAIL, PHONENUMBER, USERNAME, GENDER, P_TYPE) VALUES 
('Kagiso', 'Ndlovu', 'kagiso@aqualon.co.za', '0612345678', 'kagiso.n', 'Male', 'STAFF'),
('Mpho', 'Matabane', 'mpho@aqualon.co.za', '0712345678', 'mpho.m', 'Female', 'STAFF'),
('Sipho', 'Nkosi', 'sipho@aqualon.co.za', '0812345678', 'sipho.n', 'Male', 'STAFF'),

('Cyabonga', 'Sithole', 'cyabonga@aqualon.co.za', '0733428419', 'Cyabonga', 'Male', 'ITADMINS'),
('Samukele', 'Soetsang', 'soetsangs@gmail.com', '0753532463', 'Samukele', 'Male', 'ITADMINS'),
('John', 'Doe', 'john.admin@aqualon.co.za', '0624324345', 'johnd', 'Male', 'ITADMINS'),

('Thabo', 'Mbeki', 'thabo@gmail.com', '0821112233', 'thabom', 'Male', 'CUSTOMERS'),
('Lerato', 'Moloi', 'lerato@yahoo.com', '0832223344', 'leratom', 'Female', 'CUSTOMERS'),
('Zanele', 'Zungu', 'zanele@webmail.co.za', '0843334455', 'zanelez', 'Female', 'CUSTOMERS'),

('Junior', 'Mbeki', 'junior@gmail.com', '0821112233', 'junior_m', 'Male', 'DEPENDENTS'),
('Princess', 'Moloi', 'princess@yahoo.com', '0832223344', 'princess_m', 'Female', 'DEPENDENTS'),
('Buhle', 'Zungu', 'buhle@webmail.co.za', '0843334455', 'buhle_z', 'Female', 'DEPENDENTS');

-- 10. STAFF (Links to Persons 1, 2, 3)
INSERT INTO STAFF (FACILITY_ID, PERSON_ID) VALUES 
(1, 1), 
(2, 2), 
(3, 3);

-- 11. ITADMINS (Links to Persons 4, 5, 6)
INSERT INTO ITADMINS (PERSON_ID, FACILITY_ID) VALUES 
(4, 1), 
(5, 2), 
(6, 3);

-- 12. CUSTOMERS (Links to Persons 7, 8, 9)
INSERT INTO CUSTOMERS (PERSON_ID) VALUES 
(7), 
(8), 
(9);

-- 13. DEPENDENTS (Links to Persons 10, 11, 12, Age MUST be >= 0)
INSERT INTO DEPENDENTS (PERSON_ID, AGE, CONTACT_NO, DURATION_TIME, BOOKING_DATE, ATTENDEE_TYPE) VALUES 
(10, 12, '0821112233', '2 Hours', '2026-11-01', 'Child'),
(11, 8, '0832223344', '1 Hour', '2026-11-01', 'Child'),
(12, 15, '0843334455', '3 Hours', '2026-11-02', 'Teen');

-- 14. BOOKINGS (Num Adults MUST be > 0)
INSERT INTO BOOKINGS (CUSTOMER_ID, DATE_ID, SFBTID, NUM_ADULT, DURATION_TERM, BOOKING_DATE) VALUES 
(1, 1, 1, 2, 'Full Day', '2026-11-01'),
(2, 2, 2, 1, 'Morning Session', '2026-11-01'),
(3, 3, 3, 1, 'Monthly', '2026-11-02');

-- 15. INCIDENTS 
INSERT INTO INCIDENTS (FACILITY_ID, DESCRIPTION, DATEOFINCIDENT, CONDITION, PERSON_ID) VALUES 
(1, 'Broken shower tap in men''s changing room', '2026-10-25', 'Requires Plumber', 1),
(2, 'Chemical imbalance, high chlorine levels', '2026-10-26', 'Critical', 2),
(3, 'Loose floor tile near the shallow end', '2026-10-27', 'Safety Hazard', 3);

-- 16. MAINTENANCE_LOGS (Start Date MUST be <= End Date)
INSERT INTO MAINTENANCE_LOGS (FACILITY_ID, STAFF_ID, STATUS, INCIDENT_ID, START_DATE, END_DATE) VALUES 
(1, 1, 'Resolved', 1, '2026-10-26', '2026-10-26'),
(2, 2, 'In Progress', 2, '2026-10-27', NULL),
(3, 3, 'Pending Allocation', 3, NULL, NULL);

-- Links to Facilities (1, 2, 3 or NULL) and Persons (Using ITAdmins 4 and 5)
INSERT INTO ANNOUNCEMENTS (TITLE, CATEGORY, BODY, FACILITY_ID, PERSON_ID, STATUS, EXPIRY_DATE) VALUES 
(
    'Pool Closure for Deep Cleaning', 
    'Maintenance', 
    'Orient Beach Pool will be closed for scheduled deep cleaning this coming weekend.', 
    2, 
    4, 
    'Active', 
    '2026-11-10'
),
(
    'Summer Holiday Hours', 
    'Operations', 
    'All East London facilities will remain open an extra hour during the upcoming December school holidays.', 
    NULL, -- NULL means it applies globally to all facilities
    5, 
    'Active', 
    '2027-01-15'
),
(
    'New Swimming Lessons Open', 
    'Programs', 
    'Registration for beginner swimming lessons at Joan Harrison Complex is now officially open.', 
    3, 
    4, 
    'Draft', 
    '2026-12-01'
);