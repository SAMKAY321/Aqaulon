require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const sql = require('mssql/msnodesqlv8');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');

const app = express();
app.use(cors()); // Allow all origins for local development (Live Server, file://, localhost)
app.use(express.json({ limit: '2mb' }));

// Serve HTML, CSS, and JS frontend files directly from the project directory
app.use(express.static(__dirname));

app.get('/', (_req, res) => {
  res.sendFile(path.join(__dirname, 'login.html'));
});

// Helper to safely format errors so they never print as '[object Object]'
function formatError(err) {
  if (!err) return 'Unknown error';
  if (typeof err === 'string') return err;
  if (Array.isArray(err)) return err.map(formatError).join('; ');
  if (err.message && err.message !== '[object Object]') return err.message;
  if (err.originalError) return formatError(err.originalError);
  try { return JSON.stringify(err); } catch { return String(err); }
}

// Windows ODBC drivers to try in order
const DRIVERS = [
  'ODBC Driver 17 for SQL Server',
  'ODBC Driver 18 for SQL Server',
  'SQL Server'
];

async function createPool() {
  const srv = process.env.DB_SERVER || 'localhost\SQLEXPRESS';
  const db = process.env.DB_DATABASE || 'Aqualonn';

  if (process.env.DB_CONNECTION_STRING) {
    const p = new sql.ConnectionPool({ connectionString: process.env.DB_CONNECTION_STRING, driver: 'msnodesqlv8' });
    await p.connect();
    console.log('[Aqualon SQL] Connected successfully using DB_CONNECTION_STRING');
    await initializeDatabase(p);
    return p;
  }

  let lastError = null;
  for (const drv of DRIVERS) {
    const extra = drv.includes('18') ? 'TrustServerCertificate=yes;Encrypt=optional;' : '';
    const connStr = `Driver={${drv}};Server=${srv};Database=${db};Trusted_Connection=yes;${extra}`;
    try {
      const p = new sql.ConnectionPool({ connectionString: connStr, driver: 'msnodesqlv8' });
      await p.connect();
      console.log(`[Aqualon SQL] Connected successfully using driver: ${drv}`);
      await initializeDatabase(p);
      return p;
    } catch (err) {
      lastError = err;
    }
  }

  console.error('[Aqualon SQL] Could not connect with any known driver. Last error:', formatError(lastError));
  throw lastError;
}

// Auto-create required application support tables and default credentials
async function initializeDatabase(p) {
  try {
    // 1. Ensure AppStorage exists
    await p.request().query(`
      IF OBJECT_ID(N'dbo.AppStorage', N'U') IS NULL
      BEGIN
        CREATE TABLE dbo.AppStorage (
          StorageKey NVARCHAR(80) NOT NULL CONSTRAINT PK_AppStorage PRIMARY KEY,
          PayloadJson NVARCHAR(MAX) NOT NULL,
          UpdatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_AppStorage_UpdatedAt DEFAULT SYSUTCDATETIME()
        );
      END;
    `);

    // 2. Ensure PERSON_AUTH exists
    await p.request().query(`
      IF OBJECT_ID(N'dbo.PERSON_AUTH', N'U') IS NULL
      BEGIN
        CREATE TABLE dbo.PERSON_AUTH (
          PERSON_ID BIGINT NOT NULL CONSTRAINT PK_PERSON_AUTH PRIMARY KEY,
          PASSWORD_HASH NVARCHAR(255) NOT NULL,
          RESET_TOKEN_HASH CHAR(64) NULL,
          RESET_TOKEN_EXPIRES_AT DATETIME2(0) NULL,
          UPDATED_AT DATETIME2(0) NOT NULL CONSTRAINT DF_PERSON_AUTH_UPDATED DEFAULT SYSUTCDATETIME()
        );
      END;
    `);

    // 3. Ensure default password (Password123!) is seeded for any existing persons from Aqualonn.sql
    const defaultHash = await bcrypt.hash('Password123!', 10);
    await p.request().input('defaultHash', sql.NVarChar(255), defaultHash).query(`
      INSERT INTO dbo.PERSON_AUTH (PERSON_ID, PASSWORD_HASH)
      SELECT p.PERSON_ID, @defaultHash
      FROM dbo.PERSONS p
      WHERE NOT EXISTS (SELECT 1 FROM dbo.PERSON_AUTH a WHERE a.PERSON_ID = p.PERSON_ID);
    `);

    
    // 4. Ensure STAFF_SHIFTS exists
    await p.request().query(`
      IF OBJECT_ID(N'dbo.STAFF_SHIFTS', N'U') IS NULL
      BEGIN
        CREATE TABLE dbo.STAFF_SHIFTS (
          STAFF_ID BIGINT NOT NULL CONSTRAINT PK_STAFF_SHIFTS PRIMARY KEY,
          SHIFT_HOURS NVARCHAR(120) NOT NULL,
          UPDATED_AT DATETIME2(0) NOT NULL CONSTRAINT DF_STAFF_SHIFTS_UPDATED DEFAULT SYSUTCDATETIME()
        );
      END;
    `);

    // 5. Ensure STAFF_ATTENDANCE exists
    await p.request().query(`
      IF OBJECT_ID(N'dbo.STAFF_ATTENDANCE', N'U') IS NULL
      BEGIN
        CREATE TABLE dbo.STAFF_ATTENDANCE (
          ATTENDANCE_ID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_STAFF_ATTENDANCE PRIMARY KEY,
          STAFF_ID BIGINT NULL,
          PERSON_EMAIL NVARCHAR(254) NOT NULL,
          ACTION_TYPE NVARCHAR(20) NOT NULL,
          EVENT_TIME DATETIME2(0) NOT NULL,
          CREATED_AT DATETIME2(0) NOT NULL CONSTRAINT DF_STAFF_ATTENDANCE_CREATED DEFAULT SYSUTCDATETIME()
        );
      END;
    `);

        // Note: ERD schema is followed strictly without altering existing database tables.

    console.log('[Aqualon SQL] Schema verified: AppStorage, PERSON_AUTH, STAFF_SHIFTS, and STAFF_ATTENDANCE ready (default password: Password123!).');
  } catch (initErr) {
    console.warn('[Aqualon SQL Initialization Warning]:', formatError(initErr));
  }
}

let poolPromise = null;
function pool() {
  if (!poolPromise) {
    poolPromise = createPool().catch(err => {
      poolPromise = null;
      throw err;
    });
  }
  return poolPromise;
}

function asyncRoute(fn) { return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next); }
function required(value, label) { if (value === undefined || value === null || String(value).trim() === '') throw Object.assign(new Error(`${label} is required`), { status: 400 }); }
function normalizeEmail(value) { return String(value || '').trim().toLowerCase(); }
function normalizeRole(role) {
  const value = String(role || '').trim().toLowerCase();
  if (value === 'customer' || value === 'member') return 'member';
  if (value === 'itadmin' || value === 'admin') return 'admin';
  if (value === 'staff') return 'staff';
  return value;
}
function publicUser(row) {
  return {
    id: row.PERSON_ID,
    personId: row.PERSON_ID,
    staffId: row.STAFF_ID || null,
    email: row.EMAIL,
    username: row.USERNAME,
    name: `${row.FIRSTNAME} ${row.LASTNAME || ''}`.trim(),
    role: row.ROLE,
    facility: row.FNAME || null,
    facilityId: row.FACILITY_ID || null,
    facilityKey: null,
    shiftHours: row.SHIFT_HOURS || 'Not assigned',
    workingHours: row.SHIFT_HOURS || 'Not assigned',
    profilePicture: null
  };
}


async function getPersonsColumnSupport(reqOrTx) {
  const res = await reqOrTx.query(`
    SELECT 
      COL_LENGTH(N'dbo.PERSONS', N'USERNAME') AS hasUsername,
      COL_LENGTH(N'dbo.PERSONS', N'GENDER') AS hasGender,
      COL_LENGTH(N'dbo.PERSONS', N'P_TYPE') AS hasPType
  `);
  return {
    hasUsername: res.recordset[0]?.hasUsername !== null,
    hasGender: res.recordset[0]?.hasGender !== null,
    hasPType: res.recordset[0]?.hasPType !== null
  };
}

async function resolvePTypeValue(reqOrTx, targetRole) {
  const isStaff = String(targetRole).toUpperCase() === 'STAFF';
  const defaultChar = isStaff ? 'S' : 'C';
  const defaultWord = isStaff ? 'STAFF' : 'CUSTOMERS';

  try {
    const metaRes = await reqOrTx.query(`
      SELECT c.max_length, cc.definition
      FROM sys.columns c
      LEFT JOIN sys.check_constraints cc 
        ON cc.parent_object_id = c.object_id AND cc.parent_column_id = c.column_id
      WHERE c.object_id = OBJECT_ID(N'dbo.PERSONS') AND c.name = N'P_TYPE'
    `);
    const row = metaRes.recordset[0];
    const constraint = (row?.definition || '').toUpperCase();

    if (constraint.includes(`'${defaultWord}'`)) return defaultWord;
    if (constraint.includes(`'${defaultChar}'`)) return defaultChar;
    if (row && row.max_length > 0 && row.max_length <= 2) return defaultChar;

    const sample = await reqOrTx.query(`SELECT TOP (1) P_TYPE FROM dbo.PERSONS WHERE P_TYPE IS NOT NULL`);
    const existingVal = sample.recordset[0]?.P_TYPE;
    if (existingVal && String(existingVal).trim().length > 1) {
      return defaultWord;
    }
  } catch (err) {
    console.warn('[P_TYPE resolve warning]:', err.message);
  }
  return defaultChar;
}

async function personByIdentifier(identifier, requestedRole) {
  const role = normalizeRole(requestedRole || 'member');
  if (!['member','staff','admin'].includes(role)) return null;
  const db = await pool();
  const req = db.request().input('identifier', sql.NVarChar(254), String(identifier).trim());

  let join = '';
  let facilitySelect = 'NULL AS FNAME, NULL AS FACILITY_ID';

  if (role === 'member') {
    join = `JOIN dbo.CUSTOMERS c ON c.PERSON_ID=p.PERSON_ID`;
  } else if (role === 'staff') {
    join = `JOIN dbo.STAFF s ON s.PERSON_ID=p.PERSON_ID
            LEFT JOIN dbo.SWIMMING_FACILITIES f ON f.FACILITY_ID=s.FACILITY_ID
            LEFT JOIN dbo.STAFF_SHIFTS sh ON sh.STAFF_ID=s.STAFF_ID`;
    facilitySelect = 'f.FNAME, f.FACILITY_ID, s.STAFF_ID, ISNULL(sh.SHIFT_HOURS, \'Not assigned\') AS SHIFT_HOURS';
  } else {
    join = `JOIN dbo.ITADMINS ia ON ia.PERSON_ID=p.PERSON_ID LEFT JOIN dbo.SWIMMING_FACILITIES f ON f.FACILITY_ID=ia.FACILITY_ID`;
    facilitySelect = 'f.FNAME, f.FACILITY_ID';
  }

  const hasUserCol = (await db.request().query("SELECT COL_LENGTH(N'dbo.PERSONS', N'USERNAME') AS len")).recordset[0]?.len !== null;
  const userSelect = hasUserCol ? 'p.USERNAME,' : 'p.EMAIL AS USERNAME,';
  const userWhere = hasUserCol 
    ? 'LOWER(p.EMAIL)=LOWER(@identifier) OR LOWER(p.USERNAME)=LOWER(@identifier)'
    : 'LOWER(p.EMAIL)=LOWER(@identifier)';

  const result = await req.query(`
    SELECT TOP (1) p.PERSON_ID, p.FIRSTNAME, p.LASTNAME, p.EMAIL, ${userSelect}
           ${facilitySelect}, a.PASSWORD_HASH, '${role}' AS ROLE
    FROM dbo.PERSONS p
    JOIN dbo.PERSON_AUTH a ON a.PERSON_ID=p.PERSON_ID
    ${join}
    WHERE ${userWhere}
  `);
  return result.recordset[0] || null;
}

async function personByEmail(email) {
  const db = await pool();
  const hasUserCol = (await db.request().query("SELECT COL_LENGTH(N'dbo.PERSONS', N'USERNAME') AS len")).recordset[0]?.len !== null;
  const userSelect = hasUserCol ? ', USERNAME' : ', EMAIL AS USERNAME';
  const result = await db.request().input('email', sql.NVarChar(254), normalizeEmail(email))
    .query(`SELECT TOP (1) PERSON_ID, FIRSTNAME, LASTNAME, EMAIL ${userSelect} FROM dbo.PERSONS WHERE LOWER(EMAIL)=@email`);
  return result.recordset[0] || null;
}

const APP_STORAGE_KEYS = new Set(['aqualon_system_preferences','aqualon_bookings','aqualon_incidents','aqualon_maintenance_reports','aqualon_announcements','aqualon_staff_shifts','aqualon_staff_roster','aqualon_profile_pictures']);

app.get('/api/health', asyncRoute(async (_req, res) => {
  const p = await pool();
  await p.request().query('SELECT 1 AS ok');
  res.json({ ok: true, database: process.env.DB_DATABASE || 'Aqualonn', erd: 'Aqualon Revised ERD' });
}));


// IT Admin Global Security & System Preferences
app.get('/api/system-preferences', asyncRoute(async (_req, res) => {
  const p = await pool();
  let preferences = {
    force2FA: true,
    maintenanceMode: false,
    incidentRetention: 'forever'
  };
  try {
    const r = await p.request().input('k', sql.NVarChar(80), 'aqualon_system_preferences')
      .query('SELECT PayloadJson FROM dbo.AppStorage WHERE StorageKey=@k');
    if (r.recordset[0]?.PayloadJson) {
      preferences = { ...preferences, ...JSON.parse(r.recordset[0].PayloadJson) };
    }
  } catch (e) {
    console.warn('[Aqualon SQL] System preferences fetch warning:', e.message);
  }
  res.json({ ok: true, preferences });
}));

app.put('/api/system-preferences', asyncRoute(async (req, res) => {
  const p = await pool();
  const current = req.body || {};
  const preferences = {
    force2FA: Boolean(current.force2FA),
    maintenanceMode: Boolean(current.maintenanceMode),
    incidentRetention: String(current.incidentRetention || 'forever')
  };

  const payload = JSON.stringify(preferences);
  await p.request().input('k', sql.NVarChar(80), 'aqualon_system_preferences')
    .input('payload', sql.NVarChar(sql.MAX), payload)
    .query(`MERGE dbo.AppStorage AS t USING (SELECT @k AS StorageKey, @payload AS PayloadJson) AS s ON t.StorageKey=s.StorageKey
      WHEN MATCHED THEN UPDATE SET PayloadJson=s.PayloadJson, UpdatedAt=SYSUTCDATETIME()
      WHEN NOT MATCHED THEN INSERT(StorageKey, PayloadJson) VALUES(s.StorageKey, s.PayloadJson);`);

  res.json({ ok: true, message: 'Global security and system preferences saved to database.', preferences });
}));

app.get('/api/app-storage', asyncRoute(async (_req, res) => {
  try {
    const result = await (await pool()).request().query('SELECT StorageKey,PayloadJson FROM dbo.AppStorage');
    const data = {};
    for (const row of result.recordset) {
      if (APP_STORAGE_KEYS.has(row.StorageKey)) {
        try { data[row.StorageKey] = JSON.parse(row.PayloadJson); } catch {}
      }
    }
    res.json({ data });
  } catch (err) {
    console.warn('[Aqualon SQL] /api/app-storage read warning:', formatError(err));
    res.json({ data: {} });
  }
}));

app.put('/api/app-storage/:key', asyncRoute(async (req, res) => {
  const key = req.params.key;
  if (!APP_STORAGE_KEYS.has(key)) return res.status(400).json({ error: 'This storage key is not enabled for server persistence' });
  if (!Object.prototype.hasOwnProperty.call(req.body || {}, 'value')) return res.status(400).json({ error: 'value is required' });
  const payload = JSON.stringify(req.body.value);
  if (payload.length > 1000000) return res.status(413).json({ error: 'Stored collection is too large (maximum 1 MB)' });
  await (await pool()).request().input('key', sql.NVarChar(80), key).input('payload', sql.NVarChar(sql.MAX), payload)
    .query(`MERGE dbo.AppStorage AS t USING (SELECT @key AS StorageKey,@payload AS PayloadJson) AS s ON t.StorageKey=s.StorageKey
      WHEN MATCHED THEN UPDATE SET PayloadJson=s.PayloadJson,UpdatedAt=SYSUTCDATETIME()
      WHEN NOT MATCHED THEN INSERT(StorageKey,PayloadJson) VALUES(s.StorageKey,s.PayloadJson);`);
  res.json({ ok: true, key, savedAt: new Date().toISOString() });
}));


function validateName(val, label) {
  const str = String(val || '').trim();
  if (!str) return `${label} is required`;
  if (!/^[A-Za-z\s]+$/.test(str)) {
    return `${label} must contain only letters (no numbers or special characters)`;
  }
  const words = str.split(/\s+/);
  for (const w of words) {
    if (!/^[A-Z][a-zA-Z]*$/.test(w)) {
      return `${label} must start with a capital letter`;
    }
  }
  return null;
}

function validateUsername(val) {
  const str = String(val || '').trim();
  if (!str) return 'Username is required';
  if (str.length < 3) return 'Username must be at least 3 characters';
  const letters = str.match(/[A-Za-z]/g) || [];
  if (letters.length < 3) return 'Username must contain at least 3 letters';
  return null;
}

function validateEmail(val) {
  const str = String(val || '').trim();
  if (!str || !str.includes('@')) return "Email must contain '@'";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(str)) return 'Please provide a valid email address';
  return null;
}

function validatePassword(val) {
  const str = String(val || '');
  if (str.length < 8) return 'Password must have at least 8 characters';
  if (!/[A-Z]/.test(str)) return 'Password must contain at least 1 capital letter';
  if (!/[0-9]/.test(str)) return 'Password must contain at least 1 number';
  const specials = str.match(/[^A-Za-z0-9\s]/g) || [];
  if (specials.length === 0) return 'Password must contain 1 special character';
  if (specials.length > 1) return 'Password can use only 1 special character';
  return null;
}

function validatePhone(val) {
  const str = String(val || '').trim();
  if (!str) return null;
  if (!str.startsWith('0') && !str.startsWith('+27')) {
    return 'Phone number must begin with 0 or +27';
  }
  return null;
}

app.post('/api/auth/signup', asyncRoute(async (req, res) => {
  const { username, firstName, lastName, email, phone, password, gender } = req.body || {};
  ['username','firstName','lastName','email','password'].forEach(k => required(req.body?.[k], k));
  const fnErr = validateName(firstName, 'First name');
  if (fnErr) return res.status(400).json({ error: fnErr });
  const lnErr = validateName(lastName, 'Last name');
  if (lnErr) return res.status(400).json({ error: lnErr });
  const uErr = validateUsername(username);
  if (uErr) return res.status(400).json({ error: uErr });
  const emErr = validateEmail(email);
  if (emErr) return res.status(400).json({ error: emErr });
  const phErr = validatePhone(phone);
  if (phErr) return res.status(400).json({ error: phErr });
  const passErr = validatePassword(password);
  if (passErr) return res.status(400).json({ error: passErr });
  const db = await pool();
  const tx = new sql.Transaction(db);
  await tx.begin();
  try {
    const cols = await getPersonsColumnSupport(new sql.Request(tx));
    const hasPType = cols.hasPType;
    const hasGender = cols.hasGender;
    const hasUsername = cols.hasUsername;

    let memberPType = 'C';
    if (hasPType) {
      memberPType = await resolvePTypeValue(new sql.Request(tx), 'CUSTOMERS');
    }

    let insertCols = ['FIRSTNAME', 'LASTNAME', 'EMAIL', 'PHONENUMBER'];
    let insertVals = ['@first', '@last', '@email', '@phone'];

    const request = new sql.Request(tx)
      .input('first', sql.NVarChar(100), String(firstName).trim())
      .input('last', sql.NVarChar(100), String(lastName).trim())
      .input('email', sql.NVarChar(254), normalizeEmail(email))
      .input('phone', sql.NVarChar(40), phone || null);

    if (hasUsername) {
      insertCols.push('USERNAME');
      insertVals.push('@username');
      request.input('username', sql.NVarChar(80), String(username).trim());
    }

    if (hasGender) {
      insertCols.push('GENDER');
      insertVals.push('@gender');
      request.input('gender', sql.NVarChar(30), gender || null);
    }
    if (hasPType) {
      insertCols.push('P_TYPE');
      insertVals.push('@ptype');
      request.input('ptype', sql.NVarChar(20), memberPType);
    }

    const outputUsername = hasUsername ? ', INSERTED.USERNAME' : '';
    const insertSql = `
      INSERT INTO dbo.PERSONS (${insertCols.join(', ')})
      OUTPUT INSERTED.PERSON_ID, INSERTED.FIRSTNAME, INSERTED.LASTNAME, INSERTED.EMAIL ${outputUsername}
      VALUES (${insertVals.join(', ')})
    `;

    const personResult = await request.query(insertSql);
    const person = { ...personResult.recordset[0], ROLE: 'member' };
    const hash = await bcrypt.hash(password, 12);

    await new sql.Request(tx).input('id', sql.BigInt, person.PERSON_ID).input('hash', sql.NVarChar(255), hash)
      .query('INSERT INTO dbo.PERSON_AUTH(PERSON_ID,PASSWORD_HASH) VALUES(@id,@hash)');
    await new sql.Request(tx).input('id', sql.BigInt, person.PERSON_ID).query('INSERT INTO dbo.CUSTOMERS(PERSON_ID) VALUES(@id)');

    await tx.commit();
    res.status(201).json({ user: publicUser(person) });
  } catch (e) {
    try { await tx.rollback(); } catch {}
    if (e.number === 2627 || e.number === 2601) return res.status(409).json({ error: 'That email address or username is already registered.' });
    throw e;
  }
}));

app.post('/api/auth/login', asyncRoute(async (req, res) => {
  const { email, identifier, password, role, twoFactorCode } = req.body || {};
  const loginId = identifier || email;
  required(loginId, 'email or username'); required(password, 'password');
  const selectedRole = normalizeRole(role || 'member');

  // Read Global Security & System Preferences from AppStorage
  let systemPrefs = { force2FA: false, maintenanceMode: false };
  try {
    const prefRow = await (await pool()).request().input('k', sql.NVarChar(80), 'aqualon_system_preferences')
      .query('SELECT PayloadJson FROM dbo.AppStorage WHERE StorageKey=@k');
    if (prefRow.recordset[0]?.PayloadJson) {
      systemPrefs = JSON.parse(prefRow.recordset[0].PayloadJson);
    }
  } catch {}

  // 1. System Maintenance Mode: Disable member logins during updates
  if (systemPrefs.maintenanceMode && selectedRole === 'member') {
    return res.status(503).json({
      error: 'System is currently in Maintenance Mode for database updates. Member logins are temporarily disabled. Please try again later.'
    });
  }

  const person = await personByIdentifier(loginId, selectedRole);
  if (!person || !(await bcrypt.compare(password, person.PASSWORD_HASH))) {
    return res.status(401).json({ error: 'Email/username, password, or selected role is incorrect.' });
  }

  // 2. Force 2-Factor Authentication: Require 2FA for Staff and Admins
  if (systemPrefs.force2FA && (selectedRole === 'admin' || selectedRole === 'staff')) {
    if (!twoFactorCode) {
      return res.status(200).json({
        requires2FA: true,
        message: 'Two-Factor Authentication is enforced for Staff & Admins.\n\nEnter your 6-digit authentication code to complete sign in:'
      });
    }
    const clean2FA = String(twoFactorCode).trim();
    if (!/^\d{6}$/.test(clean2FA)) {
      return res.status(401).json({ error: 'Invalid 2FA code. Please enter a valid 6-digit authentication code.' });
    }
  }

  res.json({ user: publicUser(person) });
}));

app.post('/api/auth/forgot-password', asyncRoute(async (req, res) => {
  const email = normalizeEmail(req.body?.email); required(email, 'email');
  const person = await personByEmail(email);
  const response = { message: 'If an account exists for that email, password-reset instructions have been prepared.' };
  if (!person) return res.json(response);
  const token = crypto.randomBytes(32).toString('hex');
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  await (await pool()).request().input('id', sql.BigInt, person.PERSON_ID).input('hash', sql.Char(64), tokenHash)
    .query(`UPDATE dbo.PERSON_AUTH SET RESET_TOKEN_HASH=@hash,RESET_TOKEN_EXPIRES_AT=DATEADD(MINUTE,30,SYSUTCDATETIME()),UPDATED_AT=SYSUTCDATETIME() WHERE PERSON_ID=@id`);
  const base = (process.env.APP_BASE_URL || 'http://localhost:3000').replace(/\/$/, '');
  const resetUrl = `${base}/reset-password.html?token=${encodeURIComponent(token)}`;
  if (process.env.SMTP_HOST && process.env.SMTP_FROM) {
    const nodemailer = require('nodemailer');
    const transporter = nodemailer.createTransport({ host: process.env.SMTP_HOST, port: Number(process.env.SMTP_PORT || 587), secure: String(process.env.SMTP_SECURE || 'false') === 'true', auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASSWORD } : undefined });
    await transporter.sendMail({ from: process.env.SMTP_FROM, to: person.EMAIL, subject: 'Reset your Aqualon password', text: `Use this link within 30 minutes to reset your Aqualon password: ${resetUrl}
If you did not request this, ignore this email.` });
  } else if (process.env.NODE_ENV !== 'production') {
    response.resetUrl = resetUrl;
  }
  res.json(response);
}));

app.post('/api/auth/reset-password', asyncRoute(async (req, res) => {
  const token = String(req.body?.token || '').trim();
  const password = String(req.body?.password || '');
  required(token, 'token'); required(password, 'password');
  if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters.' });
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  const db = await pool();
  const found = await db.request().input('hash', sql.Char(64), tokenHash)
    .query('SELECT PERSON_ID FROM dbo.PERSON_AUTH WHERE RESET_TOKEN_HASH=@hash AND RESET_TOKEN_EXPIRES_AT>SYSUTCDATETIME()');
  if (!found.recordset[0]) return res.status(400).json({ error: 'This reset link is invalid or has expired. Request a new one.' });
  const passwordHash = await bcrypt.hash(password, 12);
  await db.request().input('id', sql.BigInt, found.recordset[0].PERSON_ID).input('passwordHash', sql.NVarChar(255), passwordHash)
    .query('UPDATE dbo.PERSON_AUTH SET PASSWORD_HASH=@passwordHash,RESET_TOKEN_HASH=NULL,RESET_TOKEN_EXPIRES_AT=NULL,UPDATED_AT=SYSUTCDATETIME() WHERE PERSON_ID=@id');
  res.json({ message: 'Your password has been reset. You can now sign in.' });
}));

// IT Admin Staff & Member Management APIs
app.get('/api/facilities', asyncRoute(async (_req, res) => {
  const db = await pool();
  const result = await db.request().query('SELECT FACILITY_ID, FNAME, SUBURB_ID, STREETNAME FROM dbo.SWIMMING_FACILITIES ORDER BY FACILITY_ID');
  res.json({ facilities: result.recordset });
}));

app.get('/api/staff', asyncRoute(async (req, res) => {
  const db = await pool();
  const facilityId = req.query.facilityId ? Number(req.query.facilityId) : null;
  const cols = await getPersonsColumnSupport(db.request());
  const userSelect = cols.hasUsername ? 'p.USERNAME' : 'p.EMAIL AS USERNAME';
  const genderSelect = cols.hasGender ? 'p.GENDER' : 'NULL AS GENDER';

  let query = `SELECT s.STAFF_ID, s.FACILITY_ID, f.FNAME AS FACILITY_NAME,
      p.PERSON_ID, p.FIRSTNAME, p.LASTNAME, p.EMAIL, p.PHONENUMBER, ${userSelect}, ${genderSelect},
      ISNULL(sh.SHIFT_HOURS, 'Not assigned') AS SHIFT_HOURS
    FROM dbo.STAFF s JOIN dbo.PERSONS p ON p.PERSON_ID=s.PERSON_ID
    LEFT JOIN dbo.SWIMMING_FACILITIES f ON f.FACILITY_ID=s.FACILITY_ID
    LEFT JOIN dbo.STAFF_SHIFTS sh ON sh.STAFF_ID=s.STAFF_ID`;
  const request = db.request();
  if (facilityId) {
    query += ' WHERE s.FACILITY_ID=@facilityId';
    request.input('facilityId', sql.BigInt, facilityId);
  }
  query += ' ORDER BY p.FIRSTNAME, p.LASTNAME';
  const result = await request.query(query);
  res.json({ staff: result.recordset });
}));

app.post('/api/staff', asyncRoute(async (req, res) => {
  const { firstName, lastName, email, phone, facilityId, password, gender, username: requestedUsername, shiftHours } = req.body || {};
  required(firstName, 'firstName'); required(lastName, 'lastName'); required(email, 'email'); required(facilityId, 'facilityId');
  const fid = Number(facilityId);
  if (!Number.isSafeInteger(fid) || fid <= 0) return res.status(400).json({ error: 'A valid facilityId is required.' });
  if (password && String(password).length < 8) return res.status(400).json({ error: 'Temporary password must be at least 8 characters.' });
  const db = await pool();
  const tx = new sql.Transaction(db);
  await tx.begin();
  try {
    const username = String(requestedUsername || String(email).split('@')[0]).trim();

    // Check schema columns dynamically for dbo.PERSONS
    const cols = await getPersonsColumnSupport(new sql.Request(tx));
    const hasGender = cols.hasGender;
    const hasUsername = cols.hasUsername;
    const hasPType = cols.hasPType;

    let staffPType = 'S';
    if (hasPType) {
      staffPType = await resolvePTypeValue(new sql.Request(tx), 'STAFF');
    }

    const insertCols = ['FIRSTNAME', 'LASTNAME', 'EMAIL', 'PHONENUMBER'];
    const insertVals = ['@first', '@last', '@email', '@phone'];

    const personRequest = new sql.Request(tx)
      .input('first', sql.NVarChar(100), String(firstName).trim())
      .input('last', sql.NVarChar(100), String(lastName).trim())
      .input('email', sql.NVarChar(254), normalizeEmail(email))
      .input('phone', sql.NVarChar(40), phone ? String(phone).trim() : null);

    if (hasUsername) {
      insertCols.push('USERNAME');
      insertVals.push('@username');
      personRequest.input('username', sql.NVarChar(80), username);
    }
    if (hasGender) {
      insertCols.push('GENDER');
      insertVals.push('@gender');
      personRequest.input('gender', sql.NVarChar(30), gender ? String(gender).trim() : null);
    }
    if (hasPType) {
      insertCols.push('P_TYPE');
      insertVals.push('@ptype');
      personRequest.input('ptype', sql.NVarChar(20), staffPType);
    }

    const person = await personRequest.query(`INSERT INTO dbo.PERSONS (${insertCols.join(', ')})
      OUTPUT INSERTED.PERSON_ID VALUES (${insertVals.join(', ')})`);
    const personId = person.recordset[0].PERSON_ID;
    const hash = await bcrypt.hash(password || 'staff@123', 12);
    await new sql.Request(tx).input('id', sql.BigInt, personId).input('hash', sql.NVarChar(255), hash)
      .query('INSERT INTO dbo.PERSON_AUTH (PERSON_ID,PASSWORD_HASH) VALUES (@id,@hash)');
    const staff = await new sql.Request(tx).input('fid', sql.BigInt, fid).input('pid', sql.BigInt, personId)
      .query('INSERT INTO dbo.STAFF (FACILITY_ID,PERSON_ID) OUTPUT INSERTED.STAFF_ID VALUES (@fid,@pid)');
    const staffId = staff.recordset[0].STAFF_ID;
    if (shiftHours && String(shiftHours).trim()) {
      await new sql.Request(tx).input('sid', sql.BigInt, staffId).input('shift', sql.NVarChar(120), String(shiftHours).trim())
        .query('INSERT INTO dbo.STAFF_SHIFTS (STAFF_ID, SHIFT_HOURS) VALUES (@sid, @shift)');
    }
    await tx.commit();
    res.status(201).json({ ok: true, personId, staffId: staff.recordset[0].STAFF_ID, message: 'Staff added to PERSONS and STAFF.' });
  } catch (err) {
    try { await tx.rollback(); } catch {}
    if (err.number === 2627 || err.number === 2601) return res.status(409).json({ error: 'That email address or username is already registered.' });
    throw err;
  }
}));

app.put('/api/staff/:id', asyncRoute(async (req, res) => {
  const staffId = Number(req.params.id);
  required(staffId, 'staffId');
  const { firstName, lastName, email, phone, gender, password, shiftHours } = req.body || {};
  required(firstName, 'firstName'); required(lastName, 'lastName'); required(email, 'email');
  const db = await pool();
  const hasGender = (await db.request().query(`SELECT COL_LENGTH(N'dbo.PERSONS',N'GENDER') AS GENDER_LENGTH`)).recordset[0]?.GENDER_LENGTH !== null;
  const updateSet = 'FIRSTNAME=@first,LASTNAME=@last,EMAIL=@email,PHONENUMBER=@phone' + (hasGender ? ',GENDER=@gender' : '');
  const updateRequest = db.request()
    .input('id', sql.BigInt, staffId)
    .input('first', sql.NVarChar(100), String(firstName).trim())
    .input('last', sql.NVarChar(100), String(lastName).trim())
    .input('email', sql.NVarChar(254), normalizeEmail(email))
    .input('phone', sql.NVarChar(40), phone ? String(phone).trim() : null);
  if (hasGender) updateRequest.input('gender', sql.NVarChar(30), gender ? String(gender).trim() : null);
  const result = await updateRequest.query(`UPDATE p SET ${updateSet}
      FROM dbo.PERSONS p JOIN dbo.STAFF s ON s.PERSON_ID=p.PERSON_ID WHERE s.STAFF_ID=@id;
      SELECT @@ROWCOUNT AS updated;`);
  if (!result.recordset[0]?.updated) return res.status(404).json({ error: 'Staff member not found.' });
  if (password && String(password).trim()) {
    if (String(password).length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters.' });
    const lookup = await db.request().input('id', sql.BigInt, staffId)
      .query('SELECT PERSON_ID FROM dbo.STAFF WHERE STAFF_ID=@id');
    const personId = lookup.recordset[0]?.PERSON_ID;
    const hash = await bcrypt.hash(String(password), 12);
    await db.request().input('pid', sql.BigInt, personId).input('hash', sql.NVarChar(255), hash)
      .query(`IF EXISTS (SELECT 1 FROM dbo.PERSON_AUTH WHERE PERSON_ID=@pid)
        UPDATE dbo.PERSON_AUTH SET PASSWORD_HASH=@hash, UPDATED_AT=SYSUTCDATETIME() WHERE PERSON_ID=@pid
        ELSE INSERT INTO dbo.PERSON_AUTH (PERSON_ID,PASSWORD_HASH) VALUES (@pid,@hash)`);
  }
  if (shiftHours !== undefined && shiftHours !== null) {
    const shiftVal = String(shiftHours).trim() || 'Not assigned';
    await db.request().input('sid', sql.BigInt, staffId).input('shift', sql.NVarChar(120), shiftVal)
      .query(`MERGE dbo.STAFF_SHIFTS AS t
              USING (SELECT @sid AS STAFF_ID, @shift AS SHIFT_HOURS) AS s
              ON t.STAFF_ID = s.STAFF_ID
              WHEN MATCHED THEN UPDATE SET SHIFT_HOURS = s.SHIFT_HOURS, UPDATED_AT = SYSUTCDATETIME()
              WHEN NOT MATCHED THEN INSERT (STAFF_ID, SHIFT_HOURS) VALUES (s.STAFF_ID, s.SHIFT_HOURS);`);
  }
  res.json({ ok: true, message: 'Staff details and shift schedule updated.' });
}));

app.delete('/api/staff/:id', asyncRoute(async (req, res) => {
  const staffId = Number(req.params.id);
  required(staffId, 'staffId');
  const db = await pool();
  const tx = new sql.Transaction(db);
  await tx.begin();
  try {
    const cols = await getPersonsColumnSupport(new sql.Request(tx));
    const userSelect = cols.hasUsername ? 'p.USERNAME' : 'p.EMAIL AS USERNAME';
    const found = await new sql.Request(tx).input('id', sql.BigInt, staffId)
      .query(`SELECT s.STAFF_ID, s.FACILITY_ID, s.PERSON_ID, p.EMAIL, ${userSelect} 
              FROM dbo.STAFF s 
              JOIN dbo.PERSONS p ON p.PERSON_ID = s.PERSON_ID 
              WHERE s.STAFF_ID = @id`);
    if (!found.recordset.length) {
      await tx.rollback();
      return res.status(404).json({ error: 'Staff record not found.' });
    }
    const { PERSON_ID: personId, EMAIL: email, USERNAME: username } = found.recordset[0];
    const ident = String(email || username || '').trim().toLowerCase();

    const reqTx = tx.request();
    reqTx.input('id', sql.BigInt, staffId);
    reqTx.input('pid', sql.BigInt, personId);
    reqTx.input('ident', sql.NVarChar(254), ident);

    await reqTx.query(`
      -- 1. Unlink foreign keys from maintenance logs and incidents so historical records remain intact
      IF OBJECT_ID('dbo.MAINTENANCE_LOGS', 'U') IS NOT NULL
        UPDATE dbo.MAINTENANCE_LOGS SET STAFF_ID = NULL WHERE STAFF_ID = @id;

      IF OBJECT_ID('dbo.INCIDENTS', 'U') IS NOT NULL
        UPDATE dbo.INCIDENTS SET PERSON_ID = NULL WHERE PERSON_ID = @pid;

      -- 2. Delete staff attendance and shifts
      IF OBJECT_ID('dbo.STAFF_ATTENDANCE', 'U') IS NOT NULL
        DELETE FROM dbo.STAFF_ATTENDANCE WHERE STAFF_ID = @id OR LOWER(PERSON_EMAIL) = @ident;

      IF OBJECT_ID('dbo.STAFF_SHIFTS', 'U') IS NOT NULL
        DELETE FROM dbo.STAFF_SHIFTS WHERE STAFF_ID = @id;

      -- 3. Delete staff membership record
      IF OBJECT_ID('dbo.STAFF', 'U') IS NOT NULL
        DELETE FROM dbo.STAFF WHERE STAFF_ID = @id;

      -- 4. Delete login credentials in PERSON_AUTH (prevents any login attempt)
      IF OBJECT_ID('dbo.PERSON_AUTH', 'U') IS NOT NULL
        DELETE FROM dbo.PERSON_AUTH WHERE PERSON_ID = @pid;

      -- 5. Delete core person record from PERSONS
      DELETE FROM dbo.PERSONS WHERE PERSON_ID = @pid;
    `);

    await tx.commit();

    // 6. Clean profile picture from AppStorage if stored
    try {
      const storageRes = await db.request().input('key', sql.NVarChar(80), 'aqualon_profile_pictures')
        .query('SELECT PayloadJson FROM dbo.AppStorage WHERE StorageKey=@key');
      if (storageRes.recordset.length > 0) {
        const pics = JSON.parse(storageRes.recordset[0].PayloadJson) || {};
        let changed = false;
        if (email && pics[email.toLowerCase()]) { delete pics[email.toLowerCase()]; changed = true; }
        if (username && pics[username.toLowerCase()]) { delete pics[username.toLowerCase()]; changed = true; }
        if (changed) {
          await db.request().input('key', sql.NVarChar(80), 'aqualon_profile_pictures')
            .input('payload', sql.NVarChar(sql.MAX), JSON.stringify(pics))
            .query('UPDATE dbo.AppStorage SET PayloadJson=@payload, UpdatedAt=SYSUTCDATETIME() WHERE StorageKey=@key');
        }
      }
    } catch {}

    res.json({ ok: true, message: 'Staff member account successfully removed. Login credentials and profile deleted from database.' });
  } catch (err) {
    try { await tx.rollback(); } catch {}
    throw err;
  }
}));



app.delete('/api/member/account', asyncRoute(async (req, res) => {
  const identifier = req.body?.identifier || req.query?.identifier;
  if (!identifier) return res.status(400).json({ error: 'identifier is required' });
  const p = await pool();
  const ident = String(identifier).trim().toLowerCase();

  const hasUserCol = (await p.request().query("SELECT COL_LENGTH(N'dbo.PERSONS', N'USERNAME') AS len")).recordset[0]?.len !== null;
  const whereClause = hasUserCol 
    ? 'LOWER(EMAIL)=@ident OR LOWER(USERNAME)=@ident'
    : 'LOWER(EMAIL)=@ident';
  const selectCols = hasUserCol ? 'PERSON_ID, EMAIL, USERNAME' : 'PERSON_ID, EMAIL';

  const personRes = await p.request().input('ident', sql.NVarChar(254), ident)
    .query(`SELECT TOP (1) ${selectCols} FROM dbo.PERSONS WHERE ${whereClause}`);

  if (personRes.recordset.length === 0) {
    return res.json({ ok: true, message: 'Account records removed' });
  }

  const personId = personRes.recordset[0].PERSON_ID;
  const tx = new sql.Transaction(p);
  await tx.begin();
  try {
    const reqTx = tx.request();
    reqTx.input('pid', sql.BigInt, personId);
    reqTx.input('ident', sql.NVarChar(254), ident);

    await reqTx.query(`
      -- Unlink/delete bookings associated with the customer or person
      IF OBJECT_ID('dbo.BOOKINGS', 'U') IS NOT NULL
      BEGIN
        IF COL_LENGTH(N'dbo.BOOKINGS', N'PERSON_ID') IS NOT NULL
          DELETE FROM dbo.BOOKINGS WHERE PERSON_ID = @pid;
        ELSE IF COL_LENGTH(N'dbo.BOOKINGS', N'CUSTOMER_ID') IS NOT NULL
          DELETE FROM dbo.BOOKINGS WHERE CUSTOMER_ID IN (SELECT CUSTOMER_ID FROM dbo.CUSTOMERS WHERE PERSON_ID = @pid);
      END;

      IF OBJECT_ID('dbo.DEPENDENTS', 'U') IS NOT NULL
      BEGIN
        IF COL_LENGTH(N'dbo.DEPENDENTS', N'PERSON_ID') IS NOT NULL
          DELETE FROM dbo.DEPENDENTS WHERE PERSON_ID = @pid;
      END;

      IF OBJECT_ID('dbo.INCIDENTS', 'U') IS NOT NULL
      BEGIN
        IF COL_LENGTH(N'dbo.INCIDENTS', N'PERSON_ID') IS NOT NULL
          UPDATE dbo.INCIDENTS SET PERSON_ID = NULL WHERE PERSON_ID = @pid;
      END;

      IF OBJECT_ID('dbo.CUSTOMERS', 'U') IS NOT NULL
        DELETE FROM dbo.CUSTOMERS WHERE PERSON_ID = @pid;

      IF OBJECT_ID('dbo.STAFF_ATTENDANCE', 'U') IS NOT NULL
        DELETE FROM dbo.STAFF_ATTENDANCE WHERE LOWER(PERSON_EMAIL) = @ident;

      IF OBJECT_ID('dbo.STAFF_SHIFTS', 'U') IS NOT NULL
        DELETE FROM dbo.STAFF_SHIFTS WHERE STAFF_ID IN (SELECT STAFF_ID FROM dbo.STAFF WHERE PERSON_ID = @pid);

      IF OBJECT_ID('dbo.STAFF', 'U') IS NOT NULL
        DELETE FROM dbo.STAFF WHERE PERSON_ID = @pid;

      IF OBJECT_ID('dbo.PERSON_AUTH', 'U') IS NOT NULL
        DELETE FROM dbo.PERSON_AUTH WHERE PERSON_ID = @pid;

      DELETE FROM dbo.PERSONS WHERE PERSON_ID = @pid;
    `);

    await tx.commit();

    try {
      const storageRes = await p.request().input('key', sql.NVarChar(80), 'aqualon_profile_pictures')
        .query('SELECT PayloadJson FROM dbo.AppStorage WHERE StorageKey=@key');
      if (storageRes.recordset.length > 0) {
        const pics = JSON.parse(storageRes.recordset[0].PayloadJson) || {};
        if (pics[ident]) {
          delete pics[ident];
          await p.request().input('key', sql.NVarChar(80), 'aqualon_profile_pictures')
            .input('payload', sql.NVarChar(sql.MAX), JSON.stringify(pics))
            .query('UPDATE dbo.AppStorage SET PayloadJson=@payload, UpdatedAt=SYSUTCDATETIME() WHERE StorageKey=@key');
        }
      }
    } catch {}

    res.json({ ok: true, deletedPersonId: personId, message: 'Account permanently deleted from database' });
  } catch (err) {
    await tx.rollback().catch(() => {});
    throw err;
  }
}));

app.get('/api/admin/dashboard-stats', asyncRoute(async (_req, res) => {
  const p = await pool();

  let activeStaff = 0;
  try {
    const staffRes = await p.request().query('SELECT COUNT(*) AS total FROM dbo.STAFF');
    activeStaff = staffRes.recordset[0]?.total || 0;
  } catch (e) {
    console.warn('Active staff query:', e.message);
  }

  let facilityMembers = 0;
  try {
    const memRes = await p.request().query(`
      SELECT COUNT(*) AS total FROM dbo.PERSONS
      WHERE PERSON_ID NOT IN (SELECT PERSON_ID FROM dbo.STAFF)
        AND PERSON_ID NOT IN (SELECT PERSON_ID FROM dbo.ITADMINS)
    `);
    facilityMembers = memRes.recordset[0]?.total || 0;
  } catch (e) {
    try {
      const custRes = await p.request().query('SELECT COUNT(*) AS total FROM dbo.CUSTOMERS');
      facilityMembers = custRes.recordset[0]?.total || 0;
    } catch {}
  }

  let pendingIncidents = 0;
  let dbIncidents = [];
  try {
    const incRes = await p.request().query(`
      SELECT i.INCIDENT_ID, i.DESCRIPTION, i.CONDITION, i.DATEOFINCIDENT, f.FNAME AS FACILITY_NAME
      FROM dbo.INCIDENTS i
      LEFT JOIN dbo.SWIMMING_FACILITIES f ON i.FACILITY_ID = f.FACILITY_ID
      ORDER BY i.INCIDENT_ID DESC
    `);
    dbIncidents = incRes.recordset || [];
    pendingIncidents = dbIncidents.filter(r => !['Resolved', 'Closed'].includes(String(r.CONDITION || '').trim())).length;
  } catch (e) {
    console.warn('Incident query:', e.message);
  }

  try {
    const storageRes = await p.request().input('key', sql.NVarChar(80), 'aqualon_incidents')
      .query('SELECT PayloadJson FROM dbo.AppStorage WHERE StorageKey=@key');
    if (storageRes.recordset.length > 0) {
      const storeIncs = JSON.parse(storageRes.recordset[0].PayloadJson) || [];
      if (Array.isArray(storeIncs) && storeIncs.length > 0) {
        const storePending = storeIncs.filter(inc => !['Resolved', 'Closed'].includes(inc.status || inc.condition || '')).length;
        if (storePending > pendingIncidents) pendingIncidents = storePending;
      }
    }
  } catch {}

  let openMaintenance = 0;
  try {
    const maintRes = await p.request().query(`
      SELECT COUNT(*) AS total FROM dbo.MAINTENANCE_LOGS
      WHERE STATUS IS NULL OR STATUS NOT IN ('Resolved', 'Completed', 'Closed')
    `);
    openMaintenance = maintRes.recordset[0]?.total || 0;
  } catch (e) {
    console.warn('Maintenance query:', e.message);
  }
  try {
    const storageRes = await p.request().input('key', sql.NVarChar(80), 'aqualon_maintenance_reports')
      .query('SELECT PayloadJson FROM dbo.AppStorage WHERE StorageKey=@key');
    if (storageRes.recordset.length > 0) {
      const storeMaint = JSON.parse(storageRes.recordset[0].PayloadJson) || [];
      if (Array.isArray(storeMaint) && storeMaint.length > 0) {
        const openStore = storeMaint.filter(m => !['Completed', 'Resolved', 'Closed'].includes(m.status || '')).length;
        if (openStore > openMaintenance) openMaintenance = openStore;
      }
    }
  } catch {}

  let alerts = [];
  try {
    const annRes = await p.request().query(`
      SELECT TOP (3) a.TITLE, a.CATEGORY, a.BODY, f.FNAME AS FACILITY_NAME
      FROM dbo.ANNOUNCEMENTS a
      LEFT JOIN dbo.SWIMMING_FACILITIES f ON a.FACILITY_ID = f.FACILITY_ID
      ORDER BY a.ANNOUNCEMENT_ID DESC
    `);
    if (annRes.recordset.length > 0) {
      alerts = annRes.recordset.map(r => ({
        type: String(r.CATEGORY || '').toLowerCase().includes('maint') ? 'critical' : 'notice',
        title: `${r.CATEGORY || 'Notice'} • ${r.TITLE}`,
        description: r.BODY,
        meta: `${r.FACILITY_NAME || 'Main Complex'} • Active`
      }));
    }
  } catch {}

  if (alerts.length === 0 && dbIncidents.length > 0) {
    alerts = dbIncidents.slice(0, 3).map(inc => ({
      type: String(inc.CONDITION || '').toLowerCase().includes('crit') ? 'critical' : 'warning',
      title: `${inc.CONDITION || 'Incident'} • ${String(inc.DESCRIPTION || '').slice(0, 35)}...`,
      description: inc.DESCRIPTION,
      meta: `${inc.FACILITY_NAME || 'Facility'} • ${inc.DATEOFINCIDENT ? new Date(inc.DATEOFINCIDENT).toLocaleDateString() : 'Recent'}`
    }));
  }

  let traffic = [
    { day: 'Mon', count: 12, pct: 40 },
    { day: 'Tue', count: 18, pct: 65 },
    { day: 'Wed', count: 24, pct: 85 },
    { day: 'Thu', count: 20, pct: 70 },
    { day: 'Fri', count: 28, pct: 95 },
    { day: 'Sat', count: 15, pct: 50 },
    { day: 'Sun', count: 22, pct: 80 }
  ];

  try {
    const bookRes = await p.request().query(`
      SELECT DATEPART(weekday, BOOKING_DATE) AS DayOfWeek, COUNT(*) AS TotalBookings
      FROM dbo.BOOKINGS
      GROUP BY DATEPART(weekday, BOOKING_DATE)
    `);
    if (bookRes.recordset.length > 0) {
      const dayMap = { 2: 0, 3: 1, 4: 2, 5: 3, 6: 4, 7: 5, 1: 6 };
      let counts = [0, 0, 0, 0, 0, 0, 0];
      bookRes.recordset.forEach(r => {
        const idx = dayMap[r.DayOfWeek];
        if (idx !== undefined) counts[idx] = r.TotalBookings;
      });
      const maxCount = Math.max(...counts, 1);
      const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
      traffic = days.map((d, i) => ({
        day: d,
        count: counts[i],
        pct: Math.max(15, Math.round((counts[i] / maxCount) * 100))
      }));
    }
  } catch {}

  res.json({
    activeStaff,
    facilityMembers,
    pendingIncidents,
    openMaintenance,
    alerts,
    traffic
  });
}));

app.post('/api/auth/change-password', asyncRoute(async (req, res) => {
  const { identifier, newPassword, password } = req.body || {};
  const targetPassword = newPassword || password;
  required(identifier, 'identifier');
  required(targetPassword, 'password');
  if (String(targetPassword).length < 8) {
    return res.status(400).json({ error: 'Password must be at least 8 characters long.' });
  }

  const db = await pool();
  const cols = await getPersonsColumnSupport(db.request());
  const userSelect = cols.hasUsername ? 'PERSON_ID, EMAIL, USERNAME' : 'PERSON_ID, EMAIL';
  const userWhere = cols.hasUsername 
    ? 'LOWER(EMAIL) = LOWER(@ident) OR LOWER(USERNAME) = LOWER(@ident)'
    : 'LOWER(EMAIL) = LOWER(@ident)';

  const person = await db.request().input('ident', sql.NVarChar(254), String(identifier).trim())
    .query(`SELECT TOP (1) ${userSelect} FROM dbo.PERSONS WHERE ${userWhere}`);

  const personRow = person.recordset[0];
  if (!personRow) {
    return res.status(404).json({ error: 'Account not found in the database.' });
  }

  const hash = await bcrypt.hash(String(targetPassword), 12);
  await db.request().input('pid', sql.BigInt, personRow.PERSON_ID).input('hash', sql.NVarChar(255), hash)
    .query(`MERGE dbo.PERSON_AUTH AS t
            USING (SELECT @pid AS PERSON_ID, @hash AS PASSWORD_HASH) AS s
            ON t.PERSON_ID = s.PERSON_ID
            WHEN MATCHED THEN UPDATE SET PASSWORD_HASH = s.PASSWORD_HASH, UPDATED_AT = SYSUTCDATETIME()
            WHEN NOT MATCHED THEN INSERT (PERSON_ID, PASSWORD_HASH) VALUES (s.PERSON_ID, s.PASSWORD_HASH);`);

  res.json({ ok: true, message: 'Password updated successfully in the database.' });
}));

app.post('/api/staff/clock', asyncRoute(async (req, res) => {
  const { email, action, timestamp, staffId } = req.body || {};
  required(email, 'email');
  required(action, 'action');
  const actionType = String(action).toUpperCase().includes('IN') ? 'CLOCK_IN' : 'CLOCK_OUT';
  const eventTime = timestamp ? new Date(timestamp) : new Date();

  const db = await pool();
  let resolvedStaffId = staffId ? Number(staffId) : null;
  if (!resolvedStaffId) {
    const cols = await getPersonsColumnSupport(db.request());
    const userWhere = cols.hasUsername 
      ? 'LOWER(p.EMAIL) = LOWER(@email) OR LOWER(p.USERNAME) = LOWER(@email)'
      : 'LOWER(p.EMAIL) = LOWER(@email)';
    const lookup = await db.request().input('email', sql.NVarChar(254), normalizeEmail(email))
      .query(`SELECT TOP (1) s.STAFF_ID FROM dbo.STAFF s
              JOIN dbo.PERSONS p ON p.PERSON_ID = s.PERSON_ID
              WHERE ${userWhere}`);
    resolvedStaffId = lookup.recordset[0]?.STAFF_ID || null;
  }

  await db.request()
    .input('sid', sql.BigInt, resolvedStaffId)
    .input('email', sql.NVarChar(254), normalizeEmail(email))
    .input('action', sql.NVarChar(20), actionType)
    .input('eventTime', sql.DateTime2, eventTime)
    .query(`INSERT INTO dbo.STAFF_ATTENDANCE (STAFF_ID, PERSON_EMAIL, ACTION_TYPE, EVENT_TIME)
            VALUES (@sid, @email, @action, @eventTime);`);

  res.json({ ok: true, action: actionType, eventTime: eventTime.toISOString(), staffId: resolvedStaffId });
}));

app.get('/api/staff/clock-status', asyncRoute(async (req, res) => {
  const email = req.query.email;
  required(email, 'email');
  const db = await pool();
  const latest = await db.request().input('email', sql.NVarChar(254), normalizeEmail(email))
    .query(`SELECT TOP (1) ACTION_TYPE, EVENT_TIME
            FROM dbo.STAFF_ATTENDANCE
            WHERE LOWER(PERSON_EMAIL) = LOWER(@email)
            ORDER BY EVENT_TIME DESC, ATTENDANCE_ID DESC`);
  const record = latest.recordset[0];
  if (!record) {
    return res.json({ isClockedIn: false, latestEvent: null });
  }
  res.json({
    isClockedIn: record.ACTION_TYPE === 'CLOCK_IN',
    latestAction: record.ACTION_TYPE,
    eventTime: record.EVENT_TIME
  });
}));


app.post('/api/profile/picture', asyncRoute(async (req, res) => {
  const { email, identifier, profilePicture } = req.body || {};
  const ident = String(email || identifier || '').trim().toLowerCase();
  if (!ident) return res.status(400).json({ error: 'email or identifier is required' });

  const p = await pool();
  const resExisting = await p.request().input('key', sql.NVarChar(80), 'aqualon_profile_pictures')
    .query('SELECT PayloadJson FROM dbo.AppStorage WHERE StorageKey=@key');
  
  let pictures = {};
  if (resExisting.recordset.length > 0) {
    try { pictures = JSON.parse(resExisting.recordset[0].PayloadJson) || {}; } catch {}
  }

  if (profilePicture) {
    pictures[ident] = profilePicture;
  } else {
    delete pictures[ident];
  }

  const payload = JSON.stringify(pictures);
  await p.request().input('key', sql.NVarChar(80), 'aqualon_profile_pictures')
    .input('payload', sql.NVarChar(sql.MAX), payload)
    .query(`MERGE dbo.AppStorage AS t USING (SELECT @key AS StorageKey,@payload AS PayloadJson) AS s ON t.StorageKey=s.StorageKey
      WHEN MATCHED THEN UPDATE SET PayloadJson=s.PayloadJson,UpdatedAt=SYSUTCDATETIME()
      WHEN NOT MATCHED THEN INSERT(StorageKey,PayloadJson) VALUES(s.StorageKey,s.PayloadJson);`);

  res.json({ ok: true, email: ident, hasPicture: Boolean(profilePicture) });
}));

app.get('/api/profile/picture', asyncRoute(async (req, res) => {
  const ident = String(req.query.email || req.query.identifier || '').trim().toLowerCase();
  if (!ident) return res.status(400).json({ error: 'email or identifier is required' });
  const p = await pool();
  const resExisting = await p.request().input('key', sql.NVarChar(80), 'aqualon_profile_pictures')
    .query('SELECT PayloadJson FROM dbo.AppStorage WHERE StorageKey=@key');
  let profilePicture = '';
  if (resExisting.recordset.length > 0) {
    try {
      const pictures = JSON.parse(resExisting.recordset[0].PayloadJson) || {};
      profilePicture = pictures[ident] || '';
    } catch {}
  }
  res.json({ email: ident, profilePicture });
}));

app.get('/api/staff/my-profile', asyncRoute(async (req, res) => {
  const identifier = req.query.identifier || req.query.email;
  required(identifier, 'identifier');
  const db = await pool();
  const cols = await getPersonsColumnSupport(db.request());
  const userSelect = cols.hasUsername ? 'p.USERNAME' : 'p.EMAIL AS USERNAME';
  const genderSelect = cols.hasGender ? 'p.GENDER' : 'NULL AS GENDER';
  const userWhere = cols.hasUsername 
    ? 'LOWER(p.EMAIL) = LOWER(@ident) OR LOWER(p.USERNAME) = LOWER(@ident)'
    : 'LOWER(p.EMAIL) = LOWER(@ident)';

  const result = await db.request().input('ident', sql.NVarChar(254), String(identifier).trim())
    .query(`SELECT TOP (1) s.STAFF_ID, s.FACILITY_ID, f.FNAME AS FACILITY_NAME,
                   p.PERSON_ID, p.FIRSTNAME, p.LASTNAME, p.EMAIL, p.PHONENUMBER, ${userSelect}, ${genderSelect},
                   ISNULL(sh.SHIFT_HOURS, 'Not assigned') AS SHIFT_HOURS
            FROM dbo.STAFF s
            JOIN dbo.PERSONS p ON p.PERSON_ID = s.PERSON_ID
            LEFT JOIN dbo.SWIMMING_FACILITIES f ON f.FACILITY_ID = s.FACILITY_ID
            LEFT JOIN dbo.STAFF_SHIFTS sh ON sh.STAFF_ID = s.STAFF_ID
            WHERE ${userWhere}`);

  const row = result.recordset[0];
  if (!row) return res.status(404).json({ error: 'Staff profile not found.' });
  res.json({
    staffId: row.STAFF_ID,
    personId: row.PERSON_ID,
    facilityId: row.FACILITY_ID,
    facilityName: row.FACILITY_NAME,
    fullName: `${row.FIRSTNAME} ${row.LASTNAME || ''}`.trim(),
    email: row.EMAIL,
    phone: row.PHONENUMBER,
    username: row.USERNAME,
    gender: row.GENDER,
    shiftHours: row.SHIFT_HOURS
  });
}));

app.get('/api/members', asyncRoute(async (_req, res) => {
  const db = await pool();
  const cols = await getPersonsColumnSupport(db.request());
  const userSelect = cols.hasUsername ? 'p.USERNAME' : 'p.EMAIL AS USERNAME';
  const genderSelect = cols.hasGender ? 'p.GENDER' : 'NULL AS GENDER';
  const result = await db.request().query(`SELECT c.CUSTOMER_ID,p.PERSON_ID,p.FIRSTNAME,p.LASTNAME,p.EMAIL,p.PHONENUMBER,${userSelect},${genderSelect}
    FROM dbo.CUSTOMERS c JOIN dbo.PERSONS p ON p.PERSON_ID=c.PERSON_ID ORDER BY p.FIRSTNAME,p.LASTNAME`);
  res.json({ members: result.recordset });
}));

app.use((err, _req, res, _next) => {
  const message = formatError(err);
  console.error('[Aqualon API] Error details:', message);
  res.status(err.status || 500).json({ error: err.status ? err.message : `Database error: ${message}` });
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => {
  console.log(`Aqualon API listening on http://localhost:${port}; SQL database: ${process.env.DB_DATABASE || 'Aqualonn'}`);
  pool().catch(err => {
    console.error('[Aqualon SQL Startup] Database connection check failed:', formatError(err));
  });
});